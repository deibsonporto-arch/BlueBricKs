import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { ObrasListPage } from './pages/ObrasListPage';
import { ModelosPage } from './pages/ModelosPage';
import { MateriaisPage } from './pages/MateriaisPage';
import { ObraDetailPage } from './pages/ObraDetailPage';
import { VisaoGeralTab } from './pages/obra-tabs/VisaoGeralTab';
import { PmoMensalTab } from './pages/obra-tabs/PmoMensalTab';
import { DiarioDeObraTab } from './pages/obra-tabs/DiarioDeObraTab';
import { ProximaSemanaTab } from './pages/obra-tabs/ProximaSemanaTab';
import { MapaDeCotacaoTab } from './pages/obra-tabs/MapaDeCotacaoTab';
import { FinanceiroTab } from './pages/obra-tabs/FinanceiroTab';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/obras" replace />} />
        <Route path="/obras" element={<ObrasListPage />} />
        <Route path="/modelos" element={<ModelosPage />} />
        <Route path="/materiais" element={<MateriaisPage />} />
        <Route path="/obras/:id" element={<ObraDetailPage />}>
          <Route index element={<Navigate to="visao-geral" replace />} />
          <Route path="visao-geral" element={<VisaoGeralTab />} />
          <Route path="pmo-mensal" element={<PmoMensalTab />} />
          <Route path="diario-de-obra" element={<DiarioDeObraTab />} />
          <Route path="proxima-semana" element={<ProximaSemanaTab />} />
          <Route path="mapa-cotacao" element={<MapaDeCotacaoTab />} />
          <Route path="financeiro" element={<FinanceiroTab />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
