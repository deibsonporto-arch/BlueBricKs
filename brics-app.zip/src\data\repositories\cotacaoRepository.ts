import type { Cotacao } from '../../types/domain';
import { createLocalStorageRepository } from './localStorageRepository';

export const cotacaoRepository = createLocalStorageRepository<Cotacao>('cotacoes');
