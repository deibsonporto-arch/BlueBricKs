import type { ObraTemplate, TemplateAtividade, TemplateSubatividade } from '../types/domain';

const now = new Date().toISOString();

interface EtapaOutline {
  nome: string;
  subetapas: string[];
}

/** Gera a árvore de um template a partir de uma lista simples de etapas + subetapas: encadeia subetapas em sequência dentro da mesma etapa, e etapas em sequência entre si. Custos/materiais nascem zerados — o usuário ajusta depois pela tabela ou pelo modal de subatividade. */
function buildTemplateAtividades(outline: EtapaOutline[], diasPorSubetapa = 3): TemplateAtividade[] {
  let cursorOffset = 0;
  let prevAtividadeTempId: string | undefined;

  return outline.map((etapa, ei) => {
    const atividadeTempId = `a${ei}`;
    let localOffset = cursorOffset;
    let prevSubTempId: string | undefined;

    const subatividades: TemplateSubatividade[] = etapa.subetapas.map((nomeSub, si) => {
      const subTempId = `${atividadeTempId}-s${si}`;
      const sub: TemplateSubatividade = {
        tempId: subTempId,
        nome: nomeSub,
        dependeDeTempId: prevSubTempId,
        offsetDiasInicio: localOffset,
        duracaoDias: diasPorSubetapa,
        custoMaoDeObra: 0,
        custoMaterial: 0,
        custoAluguel: 0,
        materiaisNecessarios: [],
        maoDeObraNecessaria: [],
        equipamentosAluguel: [],
      };
      localOffset += diasPorSubetapa;
      prevSubTempId = subTempId;
      return sub;
    });

    cursorOffset = localOffset;

    const atividade: TemplateAtividade = {
      tempId: atividadeTempId,
      nome: etapa.nome,
      etapa: etapa.nome,
      dependeDeTempId: prevAtividadeTempId,
      subatividades,
    };
    prevAtividadeTempId = atividadeTempId;
    return atividade;
  });
}

const CASA_OUTLINE: EtapaOutline[] = [
  {
    nome: 'Serviços Preliminares',
    subetapas: [
      'Mobilização da equipe',
      'Instalação do canteiro de obras',
      'Instalação de tapumes e sinalização',
      'Ligações provisórias de água e energia',
      'Limpeza e preparo do terreno',
      'Demolições e retirada de entulho',
      'Locação da obra',
      'Gabarito da obra',
      'Terraplenagem e regularização do terreno',
      'Galpão provisório, almoxarifado e sanitários',
      'Controle tecnológico inicial (se necessário)',
    ],
  },
  {
    nome: 'Fundações',
    subetapas: [
      'Conferência da locação',
      'Escavação das fundações',
      'Execução de brocas/estacas (quando houver)',
      'Lastro de concreto magro',
      'Armação das fundações',
      'Concretagem das fundações',
      'Escavação das vigas baldrame',
      'Formas e armação das vigas baldrame',
      'Concretagem das vigas baldrame',
      'Desforma',
      'Impermeabilização das vigas baldrame',
      'Reaterro compactado',
    ],
  },
  {
    nome: 'Estrutura e Alvenaria',
    subetapas: [
      'Alvenaria até nível peitoril',
      'Formas dos pilares até nível peitoril',
      'Concretagem dos pilares e contravergas',
      'Alvenaria até nível vigas',
      'Vergas e contravergas',
      'Concretagem dos pilares até cobertura',
      'Montagem de vigotas e EPS',
      'Ferragem da laje',
      'Tubulações embutidas na laje',
      'Conferência pré-concretagem',
      'Concretagem da laje',
      'Cura do concreto',
      'Desforma da laje',
    ],
  },
  {
    nome: 'Cobertura',
    subetapas: [
      'Estrutura metálica ou madeiramento',
      'Pintura da estrutura metálica',
      'Instalação das telhas',
      'Calhas e rufos',
      'Condutores pluviais',
      "Caixa d'água",
      'Impermeabilizações da cobertura',
    ],
  },
  {
    nome: 'Instalações Hidrossanitárias (Embutidas)',
    subetapas: [
      'Rede de esgoto',
      'Rede de água fria',
      'Rede de água quente (quando houver)',
      'Caixa de gordura',
      'Caixas de inspeção',
      'Drenos de ar-condicionado',
      'Rede pluvial',
      'Barrilete',
      'Teste de estanqueidade',
      'Rede externa de esgoto',
      'Rede externa de águas pluviais',
    ],
  },
  {
    nome: 'Instalações Elétricas e Telecom (Embutidas)',
    subetapas: [
      'Eletrodutos',
      'Caixas de passagem',
      'Infraestrutura para internet',
      'Infraestrutura para câmeras',
      'Infraestrutura para interfone',
      'Infraestrutura para automação (quando houver)',
    ],
  },
  {
    nome: 'Revestimentos de Parede',
    subetapas: [
      'Chapisco interno',
      'Emboço interno',
      'Reboco interno',
      'Chapisco externo',
      'Emboço externo',
      'Reboco externo',
      'Regularizações',
    ],
  },
  {
    nome: 'Contrapiso e Impermeabilização',
    subetapas: [
      'Impermeabilização de áreas molhadas',
      'Impermeabilização de sacadas',
      'Teste de estanqueidade',
      'Contrapiso interno',
      'Contrapiso externo',
      'Regularização para revestimentos',
    ],
  },
  {
    nome: 'Forro e Gesso',
    subetapas: [
      'Forro de gesso',
      'Cortineiros',
      'Sancas',
      'Fechamentos de shaft',
      'Tratamento de juntas',
      'Lixamento',
    ],
  },
  {
    nome: 'Revestimentos',
    subetapas: [
      'Porcelanato interno',
      'Revestimento de banheiros',
      'Revestimento de cozinha',
      'Revestimento área gourmet',
      'Soleiras',
      'Peitoris',
      'Rodapés',
    ],
  },
  {
    nome: 'Esquadrias',
    subetapas: [
      'Contramarcos',
      'Portas de madeira',
      'Janelas de alumínio',
      'Portas de vidro/alumínio',
      'Ferragens',
      'Ajustes e vedações',
    ],
  },
  {
    nome: 'Marmoraria',
    subetapas: [
      'Bancadas de banheiros',
      'Bancada da cozinha',
      'Nichos',
      'Soleiras especiais',
      'Pingadeiras',
    ],
  },
  {
    nome: 'Pintura',
    subetapas: [
      'Correções de superfície',
      'Massa corrida interna',
      'Selador',
      'Pintura interna',
      'Pintura externa',
      'Pintura de tetos',
      'Pintura de esquadrias metálicas',
      'Textura e fachada',
    ],
  },
  {
    nome: 'Instalações Elétricas Finais',
    subetapas: [
      'Passagem de fios',
      'Montagem do quadro elétrico',
      'Instalação de tomadas',
      'Instalação de interruptores',
      'Instalação de luminárias',
      'Testes e comissionamento',
    ],
  },
  {
    nome: 'Louças e Metais',
    subetapas: [
      'Bacias sanitárias',
      'Cubas',
      'Torneiras',
      'Chuveiros',
      'Acessórios',
      'Tanque e lavanderia',
    ],
  },
  {
    nome: 'Climatização e Gás (se houver)',
    subetapas: [
      'Infraestrutura de ar-condicionado',
      'Instalação das condensadoras',
      'Instalação das evaporadoras',
      'Rede de gás',
      'Testes',
    ],
  },
  {
    nome: 'Área Gourmet',
    subetapas: [
      'Churrasqueira',
      'Fogão a lenha',
      'Bancadas',
      'Revestimentos',
      'Instalações complementares',
    ],
  },
  {
    nome: 'Área Externa',
    subetapas: [
      'Calçadas',
      'Guias e meio-fio',
      'Rampas',
      'Piso intertravado',
      'Drenagem externa',
      'Muros',
      'Portões',
    ],
  },
  {
    nome: 'Paisagismo',
    subetapas: [
      'Plantio de grama',
      'Jardins',
      'Irrigação',
      'Acabamentos externos',
    ],
  },
  {
    nome: 'Limpeza, Comissionamento e Entrega',
    subetapas: [
      'Limpeza pós-obra',
      'Testes hidráulicos',
      'Testes elétricos',
      'Testes de equipamentos',
      'Lista de pendências (Punch List)',
      'Correções finais',
      'Vistoria técnica',
      'Entrega de manuais e garantias',
      'Entrega das chaves',
      'Termo de recebimento da obra',
    ],
  },
];

const GALPAO_OUTLINE: EtapaOutline[] = [
  {
    nome: 'Fundações',
    subetapas: [
      'Execução mureta técnica',
      'Ligação de água/energia',
      'Escavação de blocos e vigas baldrame',
      'Chapisco e concreto magro dos blocos e baldrame',
      'Fechamento de fôrmas das vigas baldrame',
      'Posicionamento de armaduras na fôrmas',
      'Conferência de locação dos chumbadores',
      'Concretagem dos blocos e das vigas baldrame',
      'Desfôrma das vigas baldrame',
      'Impermeabilização das vigas baldrame',
      'Reaterro e compactação',
    ],
  },
  {
    nome: 'Estrutura/Cobertura',
    subetapas: [
      'Montagem de pilares',
      'Fixação e grauteamento de bases',
      'Montagem de vigas principais',
      'Montagem de terças e contraventamentos',
      'Medição das telhas e liberação do pedido com o fornecedor',
      'Aperto de parafusos e/ou soldas de campo',
      'Alinhamento, prumo e nivelamento da estrutura',
      'Pintura anticorrosiva para estrutura metálica',
      'Inspeção estrutural',
      'Instalação de calhas',
      'Montagem de telhas de cobertura',
      'Instalação de rufos',
      'Montagem da laje nervurada - Mezanino',
      'Concretagem da laje - Mezanino',
      'Montagem da laje nervurada - Barrilete',
      'Concretagem da laje - Barrilete',
      'Instalação de rufos e pingadeiras',
    ],
  },
  {
    nome: 'Alvenaria/Vedações',
    subetapas: [
      'Marcação da 1ª fiada de blocos - Fachadas',
      'Impermeabilização da primeira fiada de blocos de concreto',
      'Alvenaria de blocos de concreto - Fachadas',
      'Paredes em Gesso Acartonado - Térreo',
      'Paredes em Gesso Acartonado - Mezanino',
      'Alvenaria de blocos de concreto - Barrilete',
    ],
  },
  {
    nome: 'Instalações Hidrossanitárias',
    subetapas: [
      'Execução de passagens na laje - Mezanino',
      'Instalações hidrossanitárias enterradas - Térreo Interno e Depósito Geral',
      'Isométrico - Térreo Interno',
      'Isométrico - Mezanino',
      'Prumadas de Água Pluvial e Água Fria',
      'Fechamento das tubulações aéreas',
      'Execução das caixas de passagem',
      'Fechamento de redes nas caixas de passagem',
      'Montagem do barrilete',
    ],
  },
  {
    nome: 'Instalações Elétricas e Telefônicas',
    subetapas: [
      'Infra estrutura elétrica e cabeamento estruturado enterradas - Térreo Interno',
      'Infra estrutura elétrica e cabeamento estruturado de parede e teto - Aparentes',
      'Infra estrutura elétrica e cabeamento estruturado de parede - Embutidas Térreo',
      'Infra estrutura elétrica e cabeamento estruturado de parede - Embutidas Mezanino',
      'Infra estrutura elétrica entreforro - Térreo Interno',
      'Infra estrutura elétrica entreforro - Mezanino',
      'Enfiação elétrica e cabeamento estruturado geral',
      'Instalação de luminárias internas - Estrutura Metálica',
      'Instalação de luminárias internas - Forro de Gesso Acartonado',
      'Montagem do quadro elétrico de distribuição',
      'Instalação de acabamentos elétricos',
    ],
  },
  {
    nome: 'Instalações de Ar Condicionado',
    subetapas: [
      'Rede frigorígena',
      'Instalação de caixinhas polares - Térreo Interno',
      'Instalação de caixinhas polares - Mezanino',
      'Instalação das evaporadoras e condensadoras',
    ],
  },
  {
    nome: 'Instalação de Sistema de Exaustão',
    subetapas: [
      'Montagem de suportes metálicos',
      'Montagem de dutos',
      'Instalação de exaustores',
      'Fixação de motores',
      'Instalação de grelhas',
      'Isolamento térmico/acústico dos dutos',
      'Teste de funcionamento dos exaustores',
    ],
  },
  {
    nome: 'Esquadrias',
    subetapas: [
      'Medição das esquadrias de vidro e alumínio - Janelas',
      'Medição das esquadrias de vidro e alumínio - Portas (combinar medidas)',
      'Medição das portas de madeira',
      'Instalação das portas de enrolar de aço',
      'Instalação das esquadrias em alumínio - Janelas',
      'Instalação das esquadrias em alumínio - Portas',
      'Instalação das portas de madeira',
    ],
  },
  {
    nome: 'Forros',
    subetapas: [
      'Gesso acartonado Mezanino - Áreas secas',
      'Gesso acartonado Mezanino - Áreas molhadas',
      'Gesso acartonado Térreo - Áreas secas',
      'Gesso acartonado Térreo - Áreas molhadas',
    ],
  },
  {
    nome: 'Revestimentos',
    subetapas: [
      'Chapisco paredes internas',
      'Reboco paredes internas',
      'Porcelanatos de paredes - Lavabo Fem/Masc, Copa, Lavabo e DML',
    ],
  },
  {
    nome: 'Pavimentação Interna',
    subetapas: [
      'Lastro de concreto - Térreo Interno',
      'Farofa de regularização - Térreo Interno',
      'Farofa de regularização - Mezanino',
      'Lastro de concreto - Depósito Geral',
      'Porcelanato de piso interno geral',
    ],
  },
  {
    nome: 'Pavimentação Externa',
    subetapas: [
      'Preparação e compactação de calçadas externas',
      'Concretagem de rampas de acesso externas',
      'Concregrama',
      'Concretagem passeio público',
    ],
  },
  {
    nome: 'Implantação',
    subetapas: [
      'Execução das caixas de passagem externas com tampa',
      'Execução de mini poço',
      'Execução de abrigo para purificador do mini poço',
      'Plantio de grama e paisagismo',
      'Instalação da escada marinheiro',
    ],
  },
  {
    nome: 'Pintura',
    subetapas: [
      'Emassamento + 1ª demão de pintura em paredes internas',
      'Emassamento + 1ª demão de pintura em forros',
      'Pintura interna de acabamento',
      'Textura Interna',
      'Textura Externa',
      'Pintura calçadas externas',
    ],
  },
  {
    nome: 'Louças e Metais',
    subetapas: ['Instalação de louças e metais'],
  },
  {
    nome: 'Marmoraria',
    subetapas: [
      'Assentamento de bancadas dos Lavabos',
      'Assentamento de bancadas da Copa e DML',
      'Assentamento de soleiras',
      'Assentamento de peitoris',
    ],
  },
  {
    nome: 'Impermeabilização',
    subetapas: ['Impermeabilização com SikaTop 100 - Áreas molhadas'],
  },
  {
    nome: 'Limpeza e Check List de Obra',
    subetapas: [
      'Limpeza grossa',
      'Check list de correções pós limpeza grossa',
      'Limpeza fina',
    ],
  },
];

export const seedTemplates: ObraTemplate[] = [
  {
    id: 'template-casa-padrao',
    tipo: 'casa',
    nome: 'Casa — Cronograma completo (20 etapas)',
    orcamentoBase: 500000,
    atividades: buildTemplateAtividades(CASA_OUTLINE),
    createdAt: now,
  },
  {
    id: 'template-galpao-padrao',
    tipo: 'galpao',
    nome: 'Galpão — Cronograma completo (18 etapas)',
    orcamentoBase: 900000,
    atividades: buildTemplateAtividades(GALPAO_OUTLINE),
    createdAt: now,
  },
];
