import { useCallback, useEffect, useState } from 'react';
import type { DiarioEntry } from '../types/domain';
import { diarioRepository } from '../data/repositories/diarioRepository';

export function useDiarioEntries(obraId: string) {
  const [entries, setEntries] = useState<DiarioEntry[]>([]);

  const refresh = useCallback(
    () =>
      setEntries(
        diarioRepository
          .list()
          .filter((e) => e.obraId === obraId)
          .sort((a, b) => (a.data < b.data ? 1 : -1)),
      ),
    [obraId],
  );
  useEffect(() => refresh(), [refresh]);

  const getByData = useCallback((data: string) => entries.find((e) => e.data === data), [entries]);

  const saveEntry = useCallback(
    async (entry: DiarioEntry) => {
      const existing = diarioRepository.list().find((e) => e.obraId === obraId && e.data === entry.data);
      if (existing) {
        diarioRepository.update(existing.id, { ...entry, id: existing.id, updatedAt: new Date().toISOString() });
      } else {
        diarioRepository.create(entry);
      }
      refresh();
    },
    [obraId, refresh],
  );

  return { entries, getByData, saveEntry, refresh };
}
