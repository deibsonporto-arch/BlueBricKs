import type { Atividade, LancamentoFinanceiro, Obra } from '../types/domain';
import { businessDaysBetween, parseISODate, todayISO } from './dateUtils';

const MONTH_NAMES = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];

export interface SCurvePoint {
  mes: string;
  previstoAcumulado: number;
  realAcumulado?: number;
}

function custoAtividade(a: Atividade): number {
  return a.custoMaoDeObra + a.custoMaterial + a.custoAluguel;
}

function duracaoAtividade(a: Atividade): number {
  return Math.max(1, businessDaysBetween(a.dataInicio, a.dataFim));
}

function buildMonthlySCurve(
  obra: Obra,
  atividades: Atividade[],
  pesoAtividade: (a: Atividade) => number,
  previstoPct: (monthEnd: Date, monthIndex: number, totalMonths: number) => number,
): SCurvePoint[] {
  const start = parseISODate(obra.dataInicio);
  const end = parseISODate(obra.previsaoEntrega);
  const today = parseISODate(todayISO());

  const points: SCurvePoint[] = [];
  const cursor = new Date(start.getFullYear(), start.getMonth(), 1);
  const totalMonths = Math.max(
    1,
    (end.getFullYear() - start.getFullYear()) * 12 + (end.getMonth() - start.getMonth()) + 1,
  );

  const pesoTotal = atividades.reduce((sum, a) => sum + pesoAtividade(a), 0) || 1;

  let monthIndex = 0;
  while (cursor <= end) {
    const monthEnd = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0);

    const realAcumulado = atividades
      .filter((a) => parseISODate(a.dataFim) <= monthEnd && a.status !== 'pendente')
      .reduce((sum, a) => sum + pesoAtividade(a), 0);

    const isFuture = cursor > today;

    points.push({
      mes: `${MONTH_NAMES[cursor.getMonth()]}/${String(cursor.getFullYear()).slice(2)}`,
      previstoAcumulado: Math.round(previstoPct(monthEnd, monthIndex, totalMonths)),
      realAcumulado: isFuture ? undefined : Math.round((realAcumulado / pesoTotal) * 100),
    });

    cursor.setMonth(cursor.getMonth() + 1);
    monthIndex += 1;
  }

  return points;
}

/** Curva S de custo: previsto = acumulação linear do orçamento ao longo dos meses; real = soma dos custos das atividades já encerradas/em andamento. */
export function buildCurvaSData(obra: Obra, atividades: Atividade[]): SCurvePoint[] {
  return buildMonthlySCurve(
    obra,
    atividades,
    custoAtividade,
    (_monthEnd, monthIndex, totalMonths) => Math.min(100, ((monthIndex + 1) / totalMonths) * 100),
  );
}

/** Curva S de cronograma (prazo): previsto = % da duração planejada das atividades com término até o mês; real = % da duração das atividades já concluídas/em andamento com término até o mês. */
export function buildCronogramaData(obra: Obra, atividades: Atividade[]): SCurvePoint[] {
  const pesoTotalDuracao = atividades.reduce((sum, a) => sum + duracaoAtividade(a), 0) || 1;

  return buildMonthlySCurve(
    obra,
    atividades,
    duracaoAtividade,
    (monthEnd) => {
      const previstoDuracao = atividades
        .filter((a) => parseISODate(a.dataFim) <= monthEnd)
        .reduce((sum, a) => sum + duracaoAtividade(a), 0);
      return (previstoDuracao / pesoTotalDuracao) * 100;
    },
  );
}

/** Curva S financeira real: previsto = acumulação de valorPrevisto dos lançamentos até o mês; real = acumulação de valorPago dos lançamentos já pagos até o mês. */
export function buildCurvaSFinanceiraFromLancamentos(obra: Obra, lancamentos: LancamentoFinanceiro[]): SCurvePoint[] {
  const start = parseISODate(obra.dataInicio);
  const end = parseISODate(obra.previsaoEntrega);
  const today = parseISODate(todayISO());
  const totalPrevisto = lancamentos.reduce((s, l) => s + l.valorPrevisto, 0) || 1;

  const points: SCurvePoint[] = [];
  const cursor = new Date(start.getFullYear(), start.getMonth(), 1);
  while (cursor <= end) {
    const monthEnd = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0);
    const previstoAcumulado = lancamentos
      .filter((l) => parseISODate(l.data) <= monthEnd)
      .reduce((s, l) => s + l.valorPrevisto, 0);
    const realAcumulado = lancamentos
      .filter((l) => l.status === 'pago' && parseISODate(l.data) <= monthEnd)
      .reduce((s, l) => s + l.valorPago, 0);
    const isFuture = cursor > today;

    points.push({
      mes: `${MONTH_NAMES[cursor.getMonth()]}/${String(cursor.getFullYear()).slice(2)}`,
      previstoAcumulado: Math.round((previstoAcumulado / totalPrevisto) * 100),
      realAcumulado: isFuture ? undefined : Math.round((realAcumulado / totalPrevisto) * 100),
    });

    cursor.setMonth(cursor.getMonth() + 1);
  }

  return points;
}

export function currentMonthLabel(): string {
  const now = new Date();
  return `${MONTH_NAMES[now.getMonth()]}/${String(now.getFullYear()).slice(2)}`;
}
