import type { Atividade, Obra, StatusAtividade } from '../../types/domain';
import { monthsBetween, pctOffset, todayISO } from '../../utils/dateUtils';
import './GanttChart.css';

interface GanttChartProps {
  obra: Obra;
  atividades: Atividade[];
  onBarClick: (atividade: Atividade) => void;
}

const STATUS_CLASS: Record<StatusAtividade, string> = {
  concluida: 'gantt-bar--concluida',
  em_andamento: 'gantt-bar--em_andamento',
  pendente: 'gantt-bar--pendente',
};

function minDate(a: string, b: string): string {
  return a < b ? a : b;
}
function maxDate(a: string, b: string): string {
  return a > b ? a : b;
}

export function GanttChart({ obra, atividades, onBarClick }: GanttChartProps) {
  if (atividades.length === 0) {
    return (
      <div className="gantt-card">
        <h3>Cronograma (Gantt)</h3>
        <p className="gantt-empty">Nenhuma atividade cadastrada ainda.</p>
      </div>
    );
  }

  const rangeStart = atividades.reduce((acc, a) => minDate(acc, a.dataInicio), obra.dataInicio);
  const rangeEnd = atividades.reduce((acc, a) => maxDate(acc, a.dataFim), obra.previsaoEntrega);

  const months = monthsBetween(rangeStart, rangeEnd);
  const today = todayISO();
  const showHoje = today >= rangeStart && today <= rangeEnd;
  const hojePct = pctOffset(rangeStart, rangeEnd, today);
  const minWidth = Math.max(600, months.length * 120);

  return (
    <div className="gantt-card">
      <h3>Cronograma (Gantt)</h3>
      <div className="scroll-x">
        <div className="gantt-wrapper" style={{ minWidth: minWidth + 220 }}>
          <div className="gantt-months-row">
            <div className="gantt-label-col" />
            <div className="gantt-timeline-col" style={{ minWidth }}>
              {months.map((m) => (
                <div key={m.key} className="gantt-month" style={{ left: `${m.startOffsetPct}%`, width: `${m.widthPct}%` }}>
                  {m.label}
                </div>
              ))}
            </div>
          </div>

          {atividades.map((a) => {
            const left = pctOffset(rangeStart, rangeEnd, a.dataInicio);
            const right = pctOffset(rangeStart, rangeEnd, a.dataFim);
            const width = Math.max(1, right - left);

            return (
              <div className="gantt-row" key={a.id}>
                <div className="gantt-label-col" title={a.nome}>{a.nome}</div>
                <div className="gantt-timeline-col" style={{ minWidth }}>
                  {showHoje && <div className="gantt-hoje-line" style={{ left: `${hojePct}%` }} />}
                  <button
                    type="button"
                    className={`gantt-bar ${STATUS_CLASS[a.status]}`}
                    style={{ left: `${left}%`, width: `${width}%` }}
                    onClick={() => onBarClick(a)}
                    title={`${a.nome} (${a.dataInicio} — ${a.dataFim})`}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="gantt-legend">
        <span><i className="gantt-bar--concluida" /> Concluída</span>
        <span><i className="gantt-bar--em_andamento" /> Em andamento</span>
        <span><i className="gantt-bar--pendente" /> Pendente</span>
      </div>
    </div>
  );
}
