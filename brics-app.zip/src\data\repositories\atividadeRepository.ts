import type { Atividade } from '../../types/domain';
import { createLocalStorageRepository } from './localStorageRepository';

export const atividadeRepository = createLocalStorageRepository<Atividade>('atividades');
