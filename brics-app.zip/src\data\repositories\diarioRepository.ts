import type { DiarioEntry } from '../../types/domain';
import { createLocalStorageRepository } from './localStorageRepository';

export const diarioRepository = createLocalStorageRepository<DiarioEntry>('diario_entries');
