import { useState } from 'react';
import { useParams } from 'react-router-dom';
import { IconBookmark } from '@tabler/icons-react';
import { useObras } from '../../hooks/useObras';
import { useAtividades } from '../../hooks/useAtividades';
import { useTemplates } from '../../hooks/useTemplates';
import { useLancamentos } from '../../hooks/useLancamentos';
import { useFornecedores } from '../../hooks/useFornecedores';
import { VisaoGeralMetrics } from '../../components/obra-detail/VisaoGeralMetrics';
import { PagamentosDoDiaCard } from '../../components/obra-detail/PagamentosDoDiaCard';
import { CurvaSSection } from '../../components/obra-detail/CurvaSSection';
import { GanttChart } from '../../components/obra-detail/GanttChart';
import { AtividadesTable } from '../../components/obra-detail/AtividadesTable';
import { AtividadeFormModal } from '../../components/obra-detail/AtividadeFormModal';
import { SubatividadeFormModal } from '../../components/obra-detail/SubatividadeFormModal';
import type { Atividade, Subatividade } from '../../types/domain';
import { businessDaysBetween } from '../../utils/dateUtils';

export function VisaoGeralTab() {
  const { id } = useParams<{ id: string }>();
  const obraId = id!;
  const { obras } = useObras();
  const obra = obras.find((o) => o.id === obraId);
  const {
    atividades,
    toggleConclusao,
    updateAtividade,
    createSubatividade,
    updateSubatividade,
    deleteSubatividade,
    reorderSubatividades,
    refresh,
  } = useAtividades(obraId);
  const { saveTemplateFromObra, updateTemplateFromObra } = useTemplates();
  const { lancamentos } = useLancamentos(obraId);
  const { fornecedores } = useFornecedores();

  const [modalOpen, setModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState<'create' | 'edit'>('create');
  const [editingAtividade, setEditingAtividade] = useState<Atividade | undefined>(undefined);
  const [templateSaved, setTemplateSaved] = useState(false);

  const [subatividadeModalOpen, setSubatividadeModalOpen] = useState(false);
  const [subatividadeModalMode, setSubatividadeModalMode] = useState<'create' | 'edit'>('create');
  const [subatividadeParentId, setSubatividadeParentId] = useState<string>('');
  const [editingSubatividade, setEditingSubatividade] = useState<Subatividade | undefined>(undefined);

  if (!obra) return null;

  function openCreate() {
    setModalMode('create');
    setEditingAtividade(undefined);
    setModalOpen(true);
  }

  function openEdit(atividade: Atividade) {
    setModalMode('edit');
    setEditingAtividade(atividade);
    setModalOpen(true);
  }

  function openNewSubatividade(atividadeId: string) {
    setSubatividadeModalMode('create');
    setEditingSubatividade(undefined);
    setSubatividadeParentId(atividadeId);
    setSubatividadeModalOpen(true);
  }

  function openEditSubatividade(atividadeId: string, subatividade: Subatividade) {
    setSubatividadeModalMode('edit');
    setEditingSubatividade(subatividade);
    setSubatividadeParentId(atividadeId);
    setSubatividadeModalOpen(true);
  }

  function handleToggleSubatividade(atividadeId: string, subatividadeId: string) {
    const atividade = atividades.find((a) => a.id === atividadeId);
    const sub = atividade?.subatividades.find((s) => s.id === subatividadeId);
    if (!sub) return;
    const willBeConcluida = !sub.concluida;
    updateSubatividade(atividadeId, subatividadeId, {
      concluida: willBeConcluida,
      status: willBeConcluida ? 'concluida' : 'pendente',
    });
  }

  async function handleSaveAsTemplate() {
    if (obra.isModelo && obra.templateOrigemId) {
      await updateTemplateFromObra(
        obra.templateOrigemId,
        obra.nome,
        obra.tipo,
        obra.orcamentoTotal,
        obra.dataInicio,
        atividades,
      );
    } else if (obra.isModelo) {
      await saveTemplateFromObra(obra.nome, obra.tipo, obra.orcamentoTotal, obra.dataInicio, atividades);
    } else {
      await saveTemplateFromObra(`Template — ${obra.nome}`, obra.tipo, obra.orcamentoTotal, obra.dataInicio, atividades);
    }
    setTemplateSaved(true);
    setTimeout(() => setTemplateSaved(false), 3000);
  }

  const totalDias = atividades.reduce((sum, a) => sum + businessDaysBetween(a.dataInicio, a.dataFim), 0);

  return (
    <div style={{ paddingBottom: 40 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 16 }}>
        <div style={{ fontSize: 14 }}>
          <strong>{obra.nome}</strong> <span style={{ color: 'var(--color-text-muted)' }}>— Total: {totalDias} dias</span>
          {obra.isModelo && (
            <span style={{ marginLeft: 10, fontSize: 11, fontWeight: 700, color: 'var(--color-primary-dark)', background: 'var(--color-primary-light)', borderRadius: 999, padding: '3px 10px' }}>
              Editando modelo
            </span>
          )}
        </div>
        <button type="button" className="btn btn-secondary" onClick={handleSaveAsTemplate} disabled={atividades.length === 0}>
          <IconBookmark size={16} /> {templateSaved ? 'Modelo salvo!' : obra.isModelo ? 'Salvar modelo' : 'Salvar cronograma como template'}
        </button>
      </div>

      <VisaoGeralMetrics obra={obra} atividades={atividades} />
      <PagamentosDoDiaCard lancamentos={lancamentos} fornecedores={fornecedores} />
      <CurvaSSection obra={obra} atividades={atividades} />
      <GanttChart obra={obra} atividades={atividades} onBarClick={openEdit} />
      <AtividadesTable
        atividades={atividades}
        onToggleConclusao={toggleConclusao}
        onUpdateAtividade={updateAtividade}
        onToggleSubatividade={handleToggleSubatividade}
        onUpdateSubatividade={updateSubatividade}
        onDeleteSubatividade={deleteSubatividade}
        onReorderSubatividades={reorderSubatividades}
        onEdit={openEdit}
        onNew={openCreate}
        onNewSubatividade={openNewSubatividade}
        onEditSubatividade={openEditSubatividade}
      />

      <AtividadeFormModal
        open={modalOpen}
        mode={modalMode}
        obraId={obraId}
        obraDataInicio={obra.dataInicio}
        atividade={editingAtividade}
        todasAtividades={atividades}
        lancamentos={lancamentos}
        onClose={() => setModalOpen(false)}
        onSaved={() => {
          setModalOpen(false);
          refresh();
        }}
      />

      <SubatividadeFormModal
        open={subatividadeModalOpen}
        mode={subatividadeModalMode}
        obraId={obraId}
        atividadeId={subatividadeParentId}
        subatividade={editingSubatividade}
        todasAtividades={atividades}
        onClose={() => setSubatividadeModalOpen(false)}
        onSaved={() => {
          setSubatividadeModalOpen(false);
          refresh();
        }}
      />
    </div>
  );
}
