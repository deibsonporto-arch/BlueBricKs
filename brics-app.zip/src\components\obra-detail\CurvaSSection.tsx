import type { Atividade, Obra } from '../../types/domain';
import { SCurveChart } from './SCurveChart';
import { buildCronogramaData, buildCurvaSData } from '../../utils/curvaS';
import './CurvaSSection.css';

interface CurvaSSectionProps {
  obra: Obra;
  atividades: Atividade[];
}

export function CurvaSSection({ obra, atividades }: CurvaSSectionProps) {
  const custoData = buildCurvaSData(obra, atividades);
  const cronogramaData = buildCronogramaData(obra, atividades);

  return (
    <div className="curva-s-section">
      <SCurveChart
        title="Cronograma — Prazo previsto x real"
        data={cronogramaData}
        previstoLabel="Prazo previsto"
        realLabel="Prazo real"
      />
      <SCurveChart
        title="Curva S — Custo previsto x real"
        data={custoData}
        previstoLabel="Custo previsto"
        realLabel="Custo real"
      />
    </div>
  );
}
