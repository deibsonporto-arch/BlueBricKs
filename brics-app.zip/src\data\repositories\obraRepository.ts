import type { Obra } from '../../types/domain';
import { createLocalStorageRepository } from './localStorageRepository';

export const obraRepository = createLocalStorageRepository<Obra>('obras');
