import { useEffect, useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import { IconCamera, IconChevronDown, IconChevronUp, IconPlus, IconTrash } from '@tabler/icons-react';
import { useAtividades } from '../../hooks/useAtividades';
import { useDiarioEntries } from '../../hooks/useDiarioEntries';
import type { DiarioEntry, DiarioFoto, DiarioRegistro, StatusAtividade } from '../../types/domain';
import { generateId } from '../../utils/id';
import { formatDate, todayISO } from '../../utils/dateUtils';
import { downloadDataUrl } from '../../utils/downloadDataUrl';
import './DiarioDeObraTab.css';

const STATUS_OPTIONS: { value: StatusAtividade; label: string }[] = [
  { value: 'pendente', label: 'Pendente' },
  { value: 'em_andamento', label: 'Em andamento' },
  { value: 'concluida', label: 'Concluída' },
];

interface EmpreitadoRow {
  id: string;
  descricao: string;
  quantidade: number;
}

function emptyForm(data: string): {
  etapaAtual: string;
  mestreDeObra: string;
  atividadesExecutadas: string;
  observacoes: string;
  pedreiros: number;
  serventes: number;
  carpinteiros: number;
  empreitados: EmpreitadoRow[];
  registros: DiarioRegistro[];
  fotos: DiarioFoto[];
  data: string;
} {
  return {
    etapaAtual: '', mestreDeObra: '', atividadesExecutadas: '', observacoes: '',
    pedreiros: 0, serventes: 0, carpinteiros: 0, empreitados: [], registros: [], fotos: [], data,
  };
}

export function DiarioDeObraTab() {
  const { id } = useParams<{ id: string }>();
  const obraId = id!;
  const { atividades } = useAtividades(obraId);
  const { entries, getByData, saveEntry } = useDiarioEntries(obraId);

  const [selectedDate, setSelectedDate] = useState(todayISO());
  const [form, setForm] = useState(() => emptyForm(todayISO()));
  const [expandedObs, setExpandedObs] = useState<Set<string>>(new Set());
  const [saved, setSaved] = useState(false);

  const etapas = useMemo(() => Array.from(new Set(atividades.map((a) => a.etapa))), [atividades]);

  useEffect(() => {
    const existing = getByData(selectedDate);
    if (existing) {
      setForm({
        etapaAtual: existing.etapaAtual,
        mestreDeObra: existing.mestreDeObra,
        atividadesExecutadas: existing.atividadesExecutadas,
        observacoes: existing.observacoes ?? '',
        pedreiros: existing.pedreiros,
        serventes: existing.serventes,
        carpinteiros: existing.carpinteiros,
        empreitados: existing.empreitados,
        registros: existing.registros,
        fotos: existing.fotos,
        data: existing.data,
      });
    } else {
      setForm(emptyForm(selectedDate));
    }
    setSaved(false);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedDate]);

  function update<K extends keyof ReturnType<typeof emptyForm>>(key: K, value: ReturnType<typeof emptyForm>[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  const totalColaboradores =
    form.pedreiros + form.serventes + form.carpinteiros + form.empreitados.reduce((s, e) => s + e.quantidade, 0);

  function handlePhotoChange(e: React.ChangeEvent<HTMLInputElement>) {
    const files = e.target.files;
    if (!files) return;
    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = reader.result as string;
        setForm((f) => ({ ...f, fotos: [...f.fotos, { id: generateId(), nome: file.name, dataUrl }] }));
      };
      reader.readAsDataURL(file);
    });
    e.target.value = '';
  }

  function removePhoto(id: string) {
    setForm((f) => ({ ...f, fotos: f.fotos.filter((p) => p.id !== id) }));
  }

  function toggleObs(registroId: string) {
    setExpandedObs((prev) => {
      const next = new Set(prev);
      if (next.has(registroId)) next.delete(registroId);
      else next.add(registroId);
      return next;
    });
  }

  function addRegistro() {
    update('registros', [
      ...form.registros,
      { id: generateId(), responsavel: '', servicoExecutado: '', status: 'em_andamento' as StatusAtividade, observacoes: '' },
    ]);
  }

  function updateRegistro(id: string, patch: Partial<DiarioRegistro>) {
    update('registros', form.registros.map((r) => (r.id === id ? { ...r, ...patch } : r)));
  }

  function removeRegistro(id: string) {
    update('registros', form.registros.filter((r) => r.id !== id));
  }

  function addEmpreitado() {
    update('empreitados', [...form.empreitados, { id: generateId(), descricao: '', quantidade: 1 }]);
  }

  function updateEmpreitado(id: string, patch: Partial<EmpreitadoRow>) {
    update('empreitados', form.empreitados.map((e) => (e.id === id ? { ...e, ...patch } : e)));
  }

  function removeEmpreitado(id: string) {
    update('empreitados', form.empreitados.filter((e) => e.id !== id));
  }

  function handleSave() {
    const now = new Date().toISOString();
    const existing = getByData(selectedDate);
    const entry: DiarioEntry = {
      id: existing?.id ?? generateId(),
      obraId,
      data: selectedDate,
      etapaAtual: form.etapaAtual,
      mestreDeObra: form.mestreDeObra,
      atividadesExecutadas: form.atividadesExecutadas,
      observacoes: form.observacoes || undefined,
      pedreiros: form.pedreiros,
      serventes: form.serventes,
      carpinteiros: form.carpinteiros,
      empreitados: form.empreitados,
      registros: form.registros,
      fotos: form.fotos,
      createdAt: existing?.createdAt ?? now,
      updatedAt: now,
    };
    saveEntry(entry).then(() => {
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    });
  }

  return (
    <div className="diario-layout" style={{ paddingBottom: 40 }}>
      <div className="diario-form-card">
        <div className="form-field" style={{ marginBottom: 16, maxWidth: 220 }}>
          <label>Data</label>
          <input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} />
        </div>

        <div className="form-grid">
          <div className="form-field">
            <label>Etapa atual</label>
            <select value={form.etapaAtual} onChange={(e) => update('etapaAtual', e.target.value)}>
              <option value="">Selecione</option>
              {etapas.map((et) => (
                <option key={et} value={et}>{et}</option>
              ))}
            </select>
          </div>
          <div className="form-field">
            <label>Mestre de obras</label>
            <input value={form.mestreDeObra} onChange={(e) => update('mestreDeObra', e.target.value)} />
          </div>

          <div className="form-field form-field--full">
            <label>Atividades executadas no dia</label>
            <textarea value={form.atividadesExecutadas} onChange={(e) => update('atividadesExecutadas', e.target.value)} />
          </div>

          <div className="form-field form-field--full">
            <label>Colaboradores</label>
            <div className="diario-colaboradores-grid">
              <div>
                <label>Pedreiros</label>
                <input type="number" min={0} value={form.pedreiros} onChange={(e) => update('pedreiros', Number(e.target.value))} />
              </div>
              <div>
                <label>Serventes</label>
                <input type="number" min={0} value={form.serventes} onChange={(e) => update('serventes', Number(e.target.value))} />
              </div>
              <div>
                <label>Carpinteiros</label>
                <input type="number" min={0} value={form.carpinteiros} onChange={(e) => update('carpinteiros', Number(e.target.value))} />
              </div>
            </div>

            <div className="diario-empreitados">
              <div className="diario-empreitados__header">
                <span>Empreitados</span>
                <button type="button" className="btn btn-ghost" onClick={addEmpreitado}>
                  <IconPlus size={14} /> Adicionar
                </button>
              </div>
              {form.empreitados.map((emp) => (
                <div className="diario-empreitados__row" key={emp.id}>
                  <input placeholder="Serviço (ex: instalação de piso)" value={emp.descricao} onChange={(e) => updateEmpreitado(emp.id, { descricao: e.target.value })} />
                  <input type="number" min={0} placeholder="Qtd" value={emp.quantidade} onChange={(e) => updateEmpreitado(emp.id, { quantidade: Number(e.target.value) })} style={{ width: 70 }} />
                  <button type="button" className="btn btn-ghost" onClick={() => removeEmpreitado(emp.id)} aria-label="Remover">
                    <IconTrash size={14} />
                  </button>
                </div>
              ))}
            </div>

            <div className="diario-total-colaboradores">Total de colaboradores no dia: <strong>{totalColaboradores}</strong></div>
          </div>

          <div className="form-field form-field--full">
            <label>Detalhamento por responsável / empreiteiro</label>
            {form.registros.map((r) => (
              <div className="diario-registro-row" key={r.id}>
                <div className="diario-registro-row__main">
                  <input placeholder="Responsável/Empreiteiro" value={r.responsavel} onChange={(e) => updateRegistro(r.id, { responsavel: e.target.value })} />
                  <input placeholder="Serviço executado" value={r.servicoExecutado} onChange={(e) => updateRegistro(r.id, { servicoExecutado: e.target.value })} />
                  <select value={r.status} onChange={(e) => updateRegistro(r.id, { status: e.target.value as StatusAtividade })}>
                    {STATUS_OPTIONS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
                  </select>
                  <button type="button" className="btn btn-ghost" onClick={() => toggleObs(r.id)}>
                    {expandedObs.has(r.id) ? <IconChevronUp size={14} /> : <IconChevronDown size={14} />} Observação
                  </button>
                  <button type="button" className="btn btn-ghost" onClick={() => removeRegistro(r.id)} aria-label="Remover registro">
                    <IconTrash size={14} />
                  </button>
                </div>
                {expandedObs.has(r.id) && (
                  <textarea
                    className="diario-registro-row__obs"
                    placeholder="Observação sobre esse registro..."
                    value={r.observacoes ?? ''}
                    onChange={(e) => updateRegistro(r.id, { observacoes: e.target.value })}
                  />
                )}
              </div>
            ))}
            <button type="button" className="btn btn-secondary" onClick={addRegistro} style={{ marginTop: 8 }}>
              <IconPlus size={14} /> Adicionar registro
            </button>
          </div>

          <div className="form-field form-field--full">
            <label>Observações / ocorrências gerais</label>
            <textarea value={form.observacoes} onChange={(e) => update('observacoes', e.target.value)} />
          </div>

          <div className="form-field form-field--full">
            <label>Fotos</label>
            <label className="btn btn-secondary diario-photo-btn">
              <IconCamera size={16} /> Tirar foto / Anexar imagem
              <input type="file" accept="image/*" capture="environment" multiple onChange={handlePhotoChange} hidden />
            </label>
            {form.fotos.length > 0 && (
              <div className="diario-fotos-grid">
                {form.fotos.map((f) => (
                  <div className="diario-foto-thumb" key={f.id}>
                    <img src={f.dataUrl} alt={f.nome} onClick={() => downloadDataUrl(f.dataUrl, f.nome)} title="Clique para baixar" />
                    <button type="button" onClick={() => removePhoto(f.id)} aria-label="Remover foto">
                      <IconTrash size={12} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <button type="button" className="btn btn-primary" onClick={handleSave} style={{ marginTop: 16 }}>
          {saved ? 'Salvo!' : 'Salvar diário'}
        </button>
      </div>

      <div className="diario-history-card">
        <h3>Histórico</h3>
        {entries.length === 0 ? (
          <p className="diario-history-empty">Nenhum diário registrado ainda.</p>
        ) : (
          <ul className="diario-history-list">
            {entries.map((e) => (
              <li key={e.id}>
                <button type="button" className={e.data === selectedDate ? 'is-active' : ''} onClick={() => setSelectedDate(e.data)}>
                  {formatDate(e.data)}
                  <span>{e.etapaAtual || 'Sem etapa'}</span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
