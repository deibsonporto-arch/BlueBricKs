import type { ListaDeMateriais } from '../../types/domain';
import { createLocalStorageRepository } from './localStorageRepository';

export const listaDeMateriaisRepository = createLocalStorageRepository<ListaDeMateriais>('listas_materiais');
