import type { LancamentoFinanceiro } from '../../types/domain';
import { createLocalStorageRepository } from './localStorageRepository';

export const lancamentoRepository = createLocalStorageRepository<LancamentoFinanceiro>('lancamentos');
