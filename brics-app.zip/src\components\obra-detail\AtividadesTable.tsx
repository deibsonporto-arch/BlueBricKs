import { Fragment, useState } from 'react';
import {
  IconChevronDown,
  IconChevronRight,
  IconEdit,
  IconGripVertical,
  IconPlayerPlay,
  IconPlayerPlayFilled,
  IconPlus,
  IconTrash,
} from '@tabler/icons-react';
import type { Atividade, Subatividade } from '../../types/domain';
import { AtividadeStatusBadge } from '../common/StatusBadge';
import { isBlocked } from '../../hooks/useAtividades';
import { addDays, businessDaysBetween, diffDays } from '../../utils/dateUtils';
import { formatBRL } from '../../utils/currency';
import { getDescendantIds, getOrderedSubatividades, getSubatividadeDisplayStatus, getTaskNumber } from '../../utils/subatividades';
import { EditableDateCell } from './EditableDateCell';
import { EditableNumberCell } from './EditableNumberCell';
import { EditablePredecessorCell } from './EditablePredecessorCell';
import './AtividadesTable.css';

interface AtividadesTableProps {
  atividades: Atividade[];
  onToggleConclusao: (id: string) => void;
  onUpdateAtividade: (id: string, patch: Partial<Atividade>) => void;
  onToggleSubatividade: (atividadeId: string, subatividadeId: string) => void;
  onUpdateSubatividade: (atividadeId: string, subatividadeId: string, patch: Partial<Subatividade>) => void;
  onDeleteSubatividade: (atividadeId: string, subatividadeId: string) => void;
  onReorderSubatividades: (atividadeId: string, idsNaNovaOrdem: string[]) => void;
  onEdit: (atividade: Atividade) => void;
  onNew: () => void;
  onNewSubatividade: (atividadeId: string) => void;
  onEditSubatividade: (atividadeId: string, subatividade: Subatividade) => void;
}

export function AtividadesTable({
  atividades,
  onToggleConclusao,
  onUpdateAtividade,
  onToggleSubatividade,
  onUpdateSubatividade,
  onDeleteSubatividade,
  onReorderSubatividades,
  onEdit,
  onNew,
  onNewSubatividade,
  onEditSubatividade,
}: AtividadesTableProps) {
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [draggedId, setDraggedId] = useState<string | null>(null);

  function toggleExpanded(id: string) {
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  function handleDrop(atividadeId: string, orderedList: Subatividade[], targetId: string) {
    if (!draggedId || draggedId === targetId) return;
    const ids = orderedList.map((s) => s.id);
    const fromIdx = ids.indexOf(draggedId);
    const toIdx = ids.indexOf(targetId);
    if (fromIdx === -1 || toIdx === -1) return;
    const newIds = [...ids];
    newIds.splice(fromIdx, 1);
    newIds.splice(toIdx, 0, draggedId);
    onReorderSubatividades(atividadeId, newIds);
    setDraggedId(null);
  }

  return (
    <div className="atividades-table-card">
      <div className="atividades-table-card__header">
        <h3>Atividades</h3>
        <button type="button" className="btn btn-primary" onClick={onNew}>
          <IconPlus size={16} /> Nova atividade
        </button>
      </div>

      <div className="scroll-x">
        <table className="atividades-table">
          <thead>
            <tr>
              <th></th>
              <th></th>
              <th>Atividade</th>
              <th>Predecessoras</th>
              <th>Início</th>
              <th>Fim</th>
              <th>Dias úteis</th>
              <th>Mão de obra</th>
              <th>Material</th>
              <th>Aluguel</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {atividades.map((a) => {
              const blocked = isBlocked(a, atividades);
              const isExpanded = expanded.has(a.id);
              const subConcluidas = a.subatividades.filter((s) => s.concluida).length;
              const temSubatividades = a.subatividades.length > 0;

              const excludedIds = new Set([a.id, ...getDescendantIds(a.id, atividades)]);
              const opcoesPredecessora = atividades
                .filter((x) => !excludedIds.has(x.id))
                .map((x) => ({ id: x.id, label: `${getTaskNumber(atividades, x.id)} — ${x.nome}` }));

              const subatividadesOrdenadas = getOrderedSubatividades(a.subatividades);

              return (
                <Fragment key={a.id}>
                  <tr className={a.concluida ? 'is-concluida' : ''}>
                    <td>
                      <button
                        type="button"
                        className="atividades-table__expand-btn"
                        onClick={() => toggleExpanded(a.id)}
                        aria-label={isExpanded ? 'Recolher subatividades' : 'Expandir subatividades'}
                      >
                        {isExpanded ? <IconChevronDown size={14} /> : <IconChevronRight size={14} />}
                      </button>
                    </td>
                    <td>
                      <input
                        type="checkbox"
                        checked={a.concluida}
                        disabled={!a.concluida && blocked}
                        title={!a.concluida && blocked ? 'Aguardando conclusão da predecessora' : undefined}
                        onChange={() => onToggleConclusao(a.id)}
                      />
                    </td>
                    <td className="atividades-table__nome">
                      <span className="atividades-table__numero">{getTaskNumber(atividades, a.id)}</span> {a.nome}
                      {temSubatividades && (
                        <span className="atividades-table__sub-count"> ({subConcluidas}/{a.subatividades.length})</span>
                      )}
                    </td>
                    <td>
                      <EditablePredecessorCell
                        value={a.dependeDe[0] ?? ''}
                        options={opcoesPredecessora}
                        onSave={(novoId) =>
                          onUpdateAtividade(a.id, { dependeDe: novoId ? [novoId] : [], updatedAt: new Date().toISOString() })
                        }
                      />
                    </td>
                    <td>
                      <EditableDateCell
                        value={a.dataInicio}
                        disabled={temSubatividades}
                        disabledTitle="Calculado a partir das subatividades"
                        onSave={(novaData) => onUpdateAtividade(a.id, { dataInicio: novaData, updatedAt: new Date().toISOString() })}
                      />
                    </td>
                    <td>
                      <EditableDateCell
                        value={a.dataFim}
                        disabled={temSubatividades}
                        disabledTitle="Calculado a partir das subatividades"
                        onSave={(novaData) => onUpdateAtividade(a.id, { dataFim: novaData, updatedAt: new Date().toISOString() })}
                      />
                    </td>
                    <td>{businessDaysBetween(a.dataInicio, a.dataFim)}</td>
                    <td>{formatBRL(a.custoMaoDeObra)}</td>
                    <td>{formatBRL(a.custoMaterial)}</td>
                    <td>{formatBRL(a.custoAluguel)}</td>
                    <td><AtividadeStatusBadge status={a.status} /></td>
                    <td>
                      <button type="button" className="btn btn-ghost" onClick={() => onEdit(a)} aria-label="Editar atividade">
                        <IconEdit size={16} />
                      </button>
                    </td>
                  </tr>
                  {isExpanded && (
                    <tr className="atividades-table__sub-row">
                      <td></td>
                      <td colSpan={11}>
                        <div className="subativ-list">
                          {subatividadesOrdenadas.map(({ subatividade: s, depth }) => {
                            const subExcluded = new Set([s.id, ...getDescendantIds(s.id, atividades)]);
                            const subOpcoes = [
                              ...atividades
                                .filter((x) => !subExcluded.has(x.id))
                                .map((x) => ({ id: x.id, label: `${getTaskNumber(atividades, x.id)} — ${x.nome}` })),
                              ...atividades.flatMap((x) =>
                                x.subatividades
                                  .filter((y) => !subExcluded.has(y.id))
                                  .map((y) => ({ id: y.id, label: `${getTaskNumber(atividades, y.id)} — ${y.nome}` })),
                              ),
                            ];

                            return (
                              <div
                                key={s.id}
                                className={`subativ-row${draggedId === s.id ? ' is-dragging' : ''}`}
                                draggable
                                onDragStart={() => setDraggedId(s.id)}
                                onDragOver={(e) => e.preventDefault()}
                                onDrop={() => handleDrop(a.id, a.subatividades, s.id)}
                              >
                                <span className="subativ-row__drag" title="Arraste para reordenar">
                                  <IconGripVertical size={14} />
                                </span>
                                <span className="subativ-row__indent" style={{ width: depth * 20 }} />
                                <input
                                  type="checkbox"
                                  checked={s.concluida}
                                  onChange={() => onToggleSubatividade(a.id, s.id)}
                                />
                                <button
                                  type="button"
                                  className={`subativ-row__iniciar-btn${s.iniciada ? ' is-iniciada' : ''}`}
                                  onClick={() => onUpdateSubatividade(a.id, s.id, { iniciada: !s.iniciada })}
                                  title={s.iniciada ? 'Marcada como iniciada' : 'Marcar como iniciada'}
                                >
                                  {s.iniciada ? <IconPlayerPlayFilled size={12} /> : <IconPlayerPlay size={12} />}
                                </button>
                                <span className="subativ-row__numero">{getTaskNumber(atividades, s.id)}</span>
                                <span className={`subativ-row__nome${s.concluida ? ' is-concluida' : ''}`}>{s.nome}</span>
                                <span className="subativ-row__campo">
                                  <EditableDateCell value={s.dataInicio} onSave={(v) => onUpdateSubatividade(a.id, s.id, { dataInicio: v })} />
                                </span>
                                <span className="subativ-row__campo-sep">—</span>
                                <span className="subativ-row__campo">
                                  <EditableDateCell value={s.dataFim} onSave={(v) => onUpdateSubatividade(a.id, s.id, { dataFim: v })} />
                                </span>
                                <span className="subativ-row__campo">
                                  <EditableNumberCell
                                    value={diffDays(s.dataInicio, s.dataFim)}
                                    suffix="d duração"
                                    onSave={(v) => onUpdateSubatividade(a.id, s.id, { dataFim: addDays(s.dataInicio, Math.max(0, v)) })}
                                  />
                                </span>
                                <span className="subativ-row__campo">
                                  <EditablePredecessorCell
                                    value={s.dependeDe}
                                    options={subOpcoes}
                                    onSave={(v) => onUpdateSubatividade(a.id, s.id, { dependeDe: v })}
                                  />
                                </span>
                                <AtividadeStatusBadge status={getSubatividadeDisplayStatus(s)} />
                                <button
                                  type="button"
                                  className="btn btn-ghost subativ-row__edit"
                                  onClick={() => onEditSubatividade(a.id, s)}
                                  aria-label="Editar subatividade"
                                >
                                  <IconEdit size={14} />
                                </button>
                                <button
                                  type="button"
                                  className="btn btn-ghost subativ-row__remove"
                                  onClick={() => onDeleteSubatividade(a.id, s.id)}
                                  aria-label="Remover subatividade"
                                >
                                  <IconTrash size={14} />
                                </button>
                              </div>
                            );
                          })}
                        </div>
                        {!temSubatividades && (
                          <p className="subativ-list__empty">Nenhuma subatividade ainda — as datas, custos e materiais desta atividade vêm das subatividades.</p>
                        )}
                        <button type="button" className="btn btn-secondary subativ-list__add" onClick={() => onNewSubatividade(a.id)}>
                          <IconPlus size={14} /> Subatividade
                        </button>
                      </td>
                    </tr>
                  )}
                </Fragment>
              );
            })}
            {atividades.length === 0 && (
              <tr>
                <td colSpan={12} className="atividades-table__empty">Nenhuma atividade cadastrada ainda.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
