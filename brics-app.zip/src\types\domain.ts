export type TipoObra = 'casa' | 'galpao' | 'condominio' | 'comercial';

export type StatusObra =
  | 'nao_iniciada'
  | 'em_andamento'
  | 'concluida'
  | 'atrasada'
  | 'paralisada';

export type StatusAtividade = 'pendente' | 'em_andamento' | 'concluida';

export type UnidadeMedida = 'un' | 'kg' | 'm' | 'm2' | 'm3' | 'saco' | 'l' | 'cx' | 'pç' | 'verba';

export interface Material {
  id: string;
  nome: string;
  quantidade: number;
  unidade: UnidadeMedida;
  custoUnitario?: number;
}

export interface MaoDeObra {
  id: string;
  tipo: string;
  quantidadePessoas: number;
  custoDiaria?: number;
}

export interface Equipamento {
  id: string;
  nome: string;
  dias: number;
  valorDia: number;
}

// ---------- Catálogo de materiais e listas ----------

export interface MaterialCatalogItem {
  id: string;
  nome: string;
  categoria: string;
  unidade: UnidadeMedida;
  custoUnitario?: number;
  createdAt: string;
  updatedAt: string;
}

export interface ListaDeMateriaisItem {
  materialId: string; // referencia MaterialCatalogItem.id
  quantidade: number;
}

export interface ListaDeMateriais {
  id: string;
  nome: string;
  itens: ListaDeMateriaisItem[];
  createdAt: string;
  updatedAt: string;
}

export interface Subatividade {
  id: string;
  nome: string;
  concluida: boolean;
  status: StatusAtividade;
  dataInicio: string;
  dataFim: string;
  dependeDe: string; // id de outra subatividade (mesmo pai ou pai diferente) — '' se nenhuma
  ordem: number;
  iniciada: boolean;
  custoMaoDeObra: number;
  custoMaterial: number;
  custoAluguel: number;
  materiaisNecessarios: Material[];
  maoDeObraNecessaria: MaoDeObra[];
  equipamentosAluguel: Equipamento[];
}

export interface Atividade {
  id: string;
  obraId: string;
  nome: string;
  etapa: string;
  dependeDe: string[];
  dataInicio: string;
  dataFim: string;
  status: StatusAtividade;
  concluida: boolean;
  custoMaoDeObra: number;
  custoMaterial: number;
  custoAluguel: number;
  materiaisNecessarios: Material[];
  maoDeObraNecessaria: MaoDeObra[];
  equipamentosAluguel: Equipamento[];
  subatividades: Subatividade[];
  createdAt: string;
  updatedAt: string;
}

export interface Endereco {
  logradouro: string;
  numero?: string;
  bairro?: string;
  cidade: string;
  estado: string;
  cep?: string;
}

export interface Obra {
  id: string;
  codigo: string;
  nome: string;
  tipo: TipoObra;
  endereco: Endereco;
  responsavelTecnico: string;
  dataInicio: string;
  previsaoEntrega: string;
  orcamentoTotal: number;
  contratoAssinado?: number;
  descricao?: string;
  status: StatusObra;
  gastoReal: number;
  colaboradoresAtivos: number;
  progressoFisico: number;
  progressoFisicoPrevisto?: number;
  templateOrigemId?: string;
  isModelo?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface TemplateSubatividade {
  tempId: string;
  nome: string;
  dependeDeTempId?: string; // tempId de outra TemplateSubatividade (mesmo "pai" ou não)
  offsetDiasInicio: number; // relativo à data de início da obra
  duracaoDias: number;
  custoMaoDeObra: number;
  custoMaterial: number;
  custoAluguel: number;
  materiaisNecessarios: Material[];
  maoDeObraNecessaria: MaoDeObra[];
  equipamentosAluguel: Equipamento[];
}

export interface TemplateAtividade {
  tempId: string;
  nome: string;
  etapa: string;
  dependeDeTempId?: string; // tempId de outra TemplateAtividade
  subatividades: TemplateSubatividade[];
}

export interface ObraTemplate {
  id: string;
  tipo: TipoObra;
  nome: string;
  orcamentoBase: number;
  atividades: TemplateAtividade[];
  createdAt: string;
}

// ---------- Módulo 3 — PMO Mensal ----------

export interface PmoEntry {
  id: string;
  obraId: string;
  atividadeId: string; // atividade pai, só para agrupar
  subatividadeId: string; // subatividade rastreada nesta linha
  mes: string; // "2026-08"
  percentualReal: number; // 0-100
  checklistSemanal: boolean[]; // um booleano por semana real do mês
  observacoes?: string; // dobra como "Pendências", igual à planilha de referência
  updatedAt: string;
}

// ---------- Diário de Obra ----------

export interface DiarioRegistro {
  id: string;
  responsavel: string;
  servicoExecutado: string;
  status: StatusAtividade;
  observacoes?: string;
}

export interface DiarioFoto {
  id: string;
  nome: string;
  dataUrl: string;
}

export interface DiarioEntry {
  id: string;
  obraId: string;
  data: string; // ISO date
  etapaAtual: string;
  mestreDeObra: string;
  atividadesExecutadas: string;
  observacoes?: string;
  pedreiros: number;
  serventes: number;
  carpinteiros: number;
  empreitados: { id: string; descricao: string; quantidade: number }[];
  registros: DiarioRegistro[];
  fotos: DiarioFoto[];
  createdAt: string;
  updatedAt: string;
}

// ---------- Módulo 5 — Mapa de Cotação ----------

export type TipoFornecedorCotacao = 'PJ' | 'Informal';
export type StatusCotacao = 'em_cotacao' | 'aguardando_aprovacao' | 'aprovado';

export interface FornecedorCotacao {
  id: string;
  nome: string;
  documento: string; // CNPJ ou CPF
  tipo: TipoFornecedorCotacao;
  marca?: string;
  numeroOrcamento?: string; // nº do orçamento/pedido dado pelo fornecedor
  valor: number;
  condicoesPagamento: string;
  prazoEntrega: string;
  emiteNF: boolean;
  observacao?: string;
}

export interface Cotacao {
  id: string;
  obraId: string;
  atividadeId?: string;
  responsavel: string;
  data: string; // ISO date
  itemServico: string;
  descricaoServico?: string;
  quantidade: number;
  unidade: UnidadeMedida;
  valorUnitarioPrevisto: number;
  servicosNaoInclusos?: string;
  condicoesPagamentoGerais?: string;
  observacoesGerais?: string;
  fornecedores: FornecedorCotacao[];
  status: StatusCotacao;
  createdAt: string;
  updatedAt: string;
}

// ---------- Módulo 4 — Próxima Semana ----------

export interface ItemProvidenciado {
  id: string;
  obraId: string;
  itemKey: string;
  providenciado: boolean;
}

// ---------- Módulo 6 — Financeiro ----------

export type TipoFornecedor = 'PJ' | 'PF' | 'Informal';

export interface Fornecedor {
  id: string;
  codigo: string;
  nome: string;
  documento: string;
  tipo: TipoFornecedor;
  contato?: string;
  cidade?: string;
  banco?: string;
  agencia?: string;
  conta?: string;
  pix?: string;
  observacoes?: string;
  createdAt: string;
  updatedAt: string;
}

export type CategoriaLancamento = 'mao_de_obra' | 'material' | 'aluguel' | 'servico' | 'taxa';
export type StatusLancamento = 'pendente' | 'pago' | 'atrasado';
export type FormaPagamento = 'pix' | 'boleto' | 'transferencia' | 'dinheiro' | 'cartao';

export interface Anexo {
  id: string;
  nome: string;
  tipo: string; // mime type
  dataUrl: string;
}

export interface HistoricoEntry {
  data: string;
  usuario: string;
  resumo: string;
}

export interface DadosPagamento {
  pixChave?: string;
  pixFavorecido?: string;
  pixBanco?: string;
  boletoLinhaDigitavel?: string;
  boletoCodigoBarras?: string;
  boletoBancoEmissor?: string;
  transferenciaBanco?: string;
  transferenciaAgencia?: string;
  transferenciaConta?: string;
  transferenciaTipoConta?: string;
}

export interface LancamentoFinanceiro {
  id: string;
  obraId: string;
  data: string;
  dataVencimento: string;
  fornecedorId?: string;
  atividadeId?: string;
  descricao: string;
  categoria: CategoriaLancamento;
  valorPrevisto: number;
  valorPago: number;
  formaPagamento: FormaPagamento;
  dadosPagamento?: DadosPagamento;
  nf: boolean;
  numeroNF?: string;
  status: StatusLancamento;
  anexos: Anexo[];
  createdBy: string;
  updatedBy: string;
  historico: HistoricoEntry[];
  createdAt: string;
  updatedAt: string;
}
