import { IconEdit, IconLink } from '@tabler/icons-react';
import type { Atividade, Fornecedor, LancamentoFinanceiro, StatusLancamento } from '../../types/domain';
import { AnexosCell } from './AnexosCell';
import { EditableStatusCell } from './EditableStatusCell';
import { formatBRL } from '../../utils/currency';
import { formatDate } from '../../utils/dateUtils';
import './LancamentosTable.css';

const CATEGORIA_LABEL: Record<LancamentoFinanceiro['categoria'], string> = {
  mao_de_obra: 'Mão de obra',
  material: 'Material',
  aluguel: 'Aluguel',
  servico: 'Serviço',
  taxa: 'Taxa',
};

interface LancamentosTableProps {
  lancamentos: LancamentoFinanceiro[];
  fornecedores: Fornecedor[];
  atividades: Atividade[];
  onEdit: (lancamento: LancamentoFinanceiro) => void;
  onFiltrarPorAtividade: (atividadeId: string) => void;
  onUpdateStatus: (lancamento: LancamentoFinanceiro, novoStatus: StatusLancamento) => void;
}

export function LancamentosTable({ lancamentos, fornecedores, atividades, onEdit, onFiltrarPorAtividade, onUpdateStatus }: LancamentosTableProps) {
  return (
    <div className="scroll-x">
      <table className="lancamentos-table">
        <thead>
          <tr>
            <th>Data</th>
            <th>Vencimento</th>
            <th>Fornecedor</th>
            <th>Descrição</th>
            <th>Atividade</th>
            <th>Categoria</th>
            <th>Valor previsto</th>
            <th>Valor pago</th>
            <th>Forma pagamento</th>
            <th>NF</th>
            <th>Anexos</th>
            <th>Status</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {lancamentos.map((l) => {
            const fornecedor = fornecedores.find((f) => f.id === l.fornecedorId);
            const atividade = atividades.find((a) => a.id === l.atividadeId);
            return (
              <tr key={l.id}>
                <td>{formatDate(l.data)}</td>
                <td>{formatDate(l.dataVencimento)}</td>
                <td>{fornecedor?.nome ?? <span className="lancamentos-table__muted">—</span>}</td>
                <td>{l.descricao}</td>
                <td>
                  {atividade ? (
                    <button type="button" className="atividade-link-pill" onClick={() => onFiltrarPorAtividade(atividade.id)}>
                      <IconLink size={12} /> {atividade.nome}
                    </button>
                  ) : (
                    <span className="lancamentos-table__muted">—</span>
                  )}
                </td>
                <td>{CATEGORIA_LABEL[l.categoria]}</td>
                <td>{formatBRL(l.valorPrevisto)}</td>
                <td>{formatBRL(l.valorPago)}</td>
                <td className="lancamentos-table__forma">{l.formaPagamento}</td>
                <td>
                  <span className={`nf-badge nf-badge--${l.nf ? 'sim' : 'nao'}`}>{l.nf ? 'Sim' : 'Não'}</span>
                </td>
                <td>
                  <AnexosCell anexos={l.anexos} />
                </td>
                <td>
                  <EditableStatusCell value={l.status} onSave={(novoStatus) => onUpdateStatus(l, novoStatus)} />
                </td>
                <td>
                  <button type="button" className="btn btn-ghost" onClick={() => onEdit(l)} aria-label="Editar lançamento">
                    <IconEdit size={16} />
                  </button>
                </td>
              </tr>
            );
          })}
          {lancamentos.length === 0 && (
            <tr>
              <td colSpan={13} className="lancamentos-table__empty">Nenhum lançamento encontrado.</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
