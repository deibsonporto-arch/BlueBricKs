import type { ObraTemplate } from '../../types/domain';
import { createLocalStorageRepository } from './localStorageRepository';

export const templateRepository = createLocalStorageRepository<ObraTemplate>('templates');
