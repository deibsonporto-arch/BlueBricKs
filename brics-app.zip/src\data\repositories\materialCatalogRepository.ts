import type { MaterialCatalogItem } from '../../types/domain';
import { createLocalStorageRepository } from './localStorageRepository';

export const materialCatalogRepository = createLocalStorageRepository<MaterialCatalogItem>('materiais_catalogo');
