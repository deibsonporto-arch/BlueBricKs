import { useEffect, useState } from 'react';
import { IconInfoCircle } from '@tabler/icons-react';
import { Modal } from '../common/Modal';
import { DynamicListField } from '../obra-detail/DynamicListField';
import type { Atividade, Cotacao, FornecedorCotacao, TipoFornecedorCotacao, UnidadeMedida } from '../../types/domain';
import { useCotacoes } from '../../hooks/useCotacoes';
import { generateId } from '../../utils/id';
import { todayISO } from '../../utils/dateUtils';
import './CotacaoFormModal.css';

interface CotacaoFormModalProps {
  open: boolean;
  obraId: string;
  atividades: Atividade[];
  defaultAtividadeId?: string;
  onClose: () => void;
  onSaved: () => void;
}

interface FormState {
  atividadeId: string;
  responsavel: string;
  data: string;
  itemServico: string;
  descricaoServico: string;
  quantidade: string;
  unidade: UnidadeMedida;
  valorUnitarioPrevisto: string;
  servicosNaoInclusos: string;
  condicoesPagamentoGerais: string;
  observacoesGerais: string;
  fornecedores: FornecedorCotacao[];
}

const UNIDADES: UnidadeMedida[] = ['un', 'kg', 'm', 'm2', 'm3', 'saco', 'l', 'cx', 'pç', 'verba'];

function estadoInicial(defaultAtividadeId?: string): FormState {
  return {
    atividadeId: defaultAtividadeId ?? '',
    responsavel: '',
    data: todayISO(),
    itemServico: '',
    descricaoServico: '',
    quantidade: '1',
    unidade: 'verba',
    valorUnitarioPrevisto: '',
    servicosNaoInclusos: '',
    condicoesPagamentoGerais: '',
    observacoesGerais: '',
    fornecedores: [],
  };
}

export function CotacaoFormModal({ open, obraId, atividades, defaultAtividadeId, onClose, onSaved }: CotacaoFormModalProps) {
  const { createCotacao } = useCotacoes(obraId);
  const [form, setForm] = useState<FormState>(() => estadoInicial(defaultAtividadeId));

  useEffect(() => {
    if (open) setForm(estadoInicial(defaultAtividadeId));
  }, [open, defaultAtividadeId]);

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const now = new Date().toISOString();
    const cotacao: Cotacao = {
      id: generateId(),
      obraId,
      atividadeId: form.atividadeId || undefined,
      responsavel: form.responsavel,
      data: form.data,
      itemServico: form.itemServico,
      descricaoServico: form.descricaoServico || undefined,
      quantidade: Number(form.quantidade) || 0,
      unidade: form.unidade,
      valorUnitarioPrevisto: Number(form.valorUnitarioPrevisto) || 0,
      servicosNaoInclusos: form.servicosNaoInclusos || undefined,
      condicoesPagamentoGerais: form.condicoesPagamentoGerais || undefined,
      observacoesGerais: form.observacoesGerais || undefined,
      fornecedores: form.fornecedores,
      status: 'em_cotacao',
      createdAt: now,
      updatedAt: now,
    };
    createCotacao(cotacao).then(onSaved);
  }

  return (
    <Modal
      open={open}
      title="Nova cotação"
      onClose={onClose}
      width={960}
      footer={
        <>
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancelar</button>
          <button type="submit" form="cotacao-form" className="btn btn-primary">Salvar</button>
        </>
      }
    >
      <form id="cotacao-form" className="form-grid" onSubmit={handleSubmit}>
        <div className="form-field form-field--full">
          <div className="banner-info">
            <IconInfoCircle size={18} style={{ flexShrink: 0 }} />
            <div>Vincular a cotação a uma atividade ajuda a rastrear o item na Próxima Semana e no Diário de Obra.</div>
          </div>
        </div>
        <div className="form-field form-field--full">
          <label>Atividade vinculada</label>
          <select value={form.atividadeId} onChange={(e) => update('atividadeId', e.target.value)}>
            <option value="">Nenhuma</option>
            {atividades.map((a) => (
              <option key={a.id} value={a.id}>{a.nome}</option>
            ))}
          </select>
        </div>

        <div className="form-field">
          <label>Responsável</label>
          <input required value={form.responsavel} onChange={(e) => update('responsavel', e.target.value)} placeholder="Quem está fazendo a cotação" />
        </div>
        <div className="form-field">
          <label>Data</label>
          <input required type="date" value={form.data} onChange={(e) => update('data', e.target.value)} />
        </div>

        <div className="form-field form-field--full">
          <label>Item / serviço</label>
          <input required value={form.itemServico} onChange={(e) => update('itemServico', e.target.value)} placeholder="Ex: Pintura Interna e Externa" />
        </div>
        <div className="form-field form-field--full">
          <label>Descrição dos serviços orçados para execução na obra</label>
          <textarea value={form.descricaoServico} onChange={(e) => update('descricaoServico', e.target.value)} placeholder="Detalhe o escopo do que está sendo cotado, item a item" style={{ minHeight: 110 }} />
        </div>

        <div className="form-field form-field--full">
          <label>Orçamento previsto</label>
        </div>
        <div className="form-field">
          <label>Quantidade</label>
          <input type="number" min={0} step="0.01" value={form.quantidade} onChange={(e) => update('quantidade', e.target.value)} />
        </div>
        <div className="form-field">
          <label>Unidade</label>
          <select value={form.unidade} onChange={(e) => update('unidade', e.target.value as UnidadeMedida)}>
            {UNIDADES.map((u) => <option key={u} value={u}>{u}</option>)}
          </select>
        </div>
        <div className="form-field form-field--full">
          <label>Valor unitário previsto (R$)</label>
          <input type="number" min={0} step="0.01" value={form.valorUnitarioPrevisto} onChange={(e) => update('valorUnitarioPrevisto', e.target.value)} />
        </div>

        <DynamicListField<FornecedorCotacao>
          label="Fornecedores (mínimo recomendado: 3)"
          items={form.fornecedores}
          onChange={(items) => update('fornecedores', items)}
          newItem={() => ({
            id: generateId(), nome: '', documento: '', tipo: 'PJ', marca: '', numeroOrcamento: '', valor: 0,
            condicoesPagamento: '', prazoEntrega: '', emiteNF: true, observacao: '',
          })}
          renderRowFields={(item, upd) => (
            <div className="cotacao-fornecedor-row">
              <input placeholder="Nome do fornecedor" value={item.nome} onChange={(e) => upd({ nome: e.target.value })} />
              <select
                value={item.tipo}
                onChange={(e) => {
                  const tipo = e.target.value as TipoFornecedorCotacao;
                  upd({ tipo, emiteNF: tipo === 'PJ' });
                }}
              >
                <option value="PJ">PJ</option>
                <option value="Informal">Autônomo/Informal</option>
              </select>
              <input
                placeholder={item.tipo === 'PJ' ? 'CNPJ' : 'CPF'}
                value={item.documento}
                onChange={(e) => upd({ documento: e.target.value })}
              />
              <input placeholder="Marca" value={item.marca} onChange={(e) => upd({ marca: e.target.value })} />
              <input placeholder="Nº orçamento" value={item.numeroOrcamento} onChange={(e) => upd({ numeroOrcamento: e.target.value })} />
              <input type="number" min={0} step="0.01" placeholder="Valor (R$)" value={item.valor} onChange={(e) => upd({ valor: Number(e.target.value) })} />
              <input placeholder="Condições de pagamento" value={item.condicoesPagamento} onChange={(e) => upd({ condicoesPagamento: e.target.value })} />
              <input placeholder="Prazo de entrega" value={item.prazoEntrega} onChange={(e) => upd({ prazoEntrega: e.target.value })} />
              <label className="cotacao-nf-toggle">
                <input type="checkbox" checked={item.emiteNF} onChange={(e) => upd({ emiteNF: e.target.checked })} />
                Emite NF
              </label>
              <input placeholder="Observação" value={item.observacao} onChange={(e) => upd({ observacao: e.target.value })} />
            </div>
          )}
        />

        <div className="form-field form-field--full">
          <label>Condições de pagamento (gerais)</label>
          <textarea value={form.condicoesPagamentoGerais} onChange={(e) => update('condicoesPagamentoGerais', e.target.value)} placeholder="Ex: pagamento mediante medições periódicas, retenção de garantia, etc." />
        </div>
        <div className="form-field form-field--full">
          <label>Serviços não inclusos</label>
          <textarea value={form.servicosNaoInclusos} onChange={(e) => update('servicosNaoInclusos', e.target.value)} placeholder="Liste o que fica de fora do escopo desta cotação" />
        </div>
        <div className="form-field form-field--full">
          <label>Observações gerais</label>
          <textarea value={form.observacoesGerais} onChange={(e) => update('observacoesGerais', e.target.value)} />
        </div>
      </form>
    </Modal>
  );
}
