import { useEffect, useState } from 'react';
import { Modal } from '../common/Modal';
import type { Atividade, LancamentoFinanceiro } from '../../types/domain';
import { useAtividades } from '../../hooks/useAtividades';
import { generateId } from '../../utils/id';
import { getDescendantIds } from '../../utils/subatividades';
import { formatBRL } from '../../utils/currency';
import { formatDate } from '../../utils/dateUtils';
import './AtividadeFormModal.css';

interface AtividadeFormModalProps {
  open: boolean;
  mode: 'create' | 'edit';
  obraId: string;
  obraDataInicio: string;
  atividade?: Atividade;
  todasAtividades: Atividade[];
  lancamentos: LancamentoFinanceiro[];
  onClose: () => void;
  onSaved: () => void;
}

interface FormState {
  nome: string;
  dependeDe: string;
}

function toFormState(a?: Atividade): FormState {
  if (!a) return { nome: '', dependeDe: '' };
  return { nome: a.nome, dependeDe: a.dependeDe[0] ?? '' };
}

export function AtividadeFormModal({ open, mode, obraId, obraDataInicio, atividade, todasAtividades, lancamentos, onClose, onSaved }: AtividadeFormModalProps) {
  const { createAtividade, updateAtividade } = useAtividades(obraId);
  const [form, setForm] = useState<FormState>(() => toFormState(atividade));

  useEffect(() => {
    if (open) setForm(toFormState(atividade));
  }, [open, atividade]);

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  const excludedIds = atividade ? new Set([atividade.id, ...getDescendantIds(atividade.id, todasAtividades)]) : new Set<string>();
  const dependeDeOptions = todasAtividades.filter((a) => !excludedIds.has(a.id));

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const now = new Date().toISOString();

    if (mode === 'create') {
      const nova: Atividade = {
        id: generateId(),
        obraId,
        nome: form.nome,
        etapa: form.nome,
        dependeDe: form.dependeDe ? [form.dependeDe] : [],
        dataInicio: obraDataInicio,
        dataFim: obraDataInicio,
        status: 'pendente',
        concluida: false,
        custoMaoDeObra: 0,
        custoMaterial: 0,
        custoAluguel: 0,
        materiaisNecessarios: [],
        maoDeObraNecessaria: [],
        equipamentosAluguel: [],
        subatividades: [],
        createdAt: now,
        updatedAt: now,
      };
      createAtividade(nova).then(onSaved);
    } else if (atividade) {
      updateAtividade(atividade.id, {
        nome: form.nome,
        etapa: form.nome,
        dependeDe: form.dependeDe ? [form.dependeDe] : [],
        updatedAt: now,
      }).then(onSaved);
    }
  }

  return (
    <Modal
      open={open}
      title={mode === 'create' ? 'Nova atividade' : 'Editar atividade'}
      onClose={onClose}
      width={480}
      footer={
        <>
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancelar</button>
          <button type="submit" form="atividade-form" className="btn btn-primary">Salvar</button>
        </>
      }
    >
      <form id="atividade-form" className="form-grid" onSubmit={handleSubmit}>
        <div className="form-field form-field--full">
          <label>Nome da atividade</label>
          <input required autoFocus value={form.nome} onChange={(e) => update('nome', e.target.value)} />
        </div>

        <div className="form-field form-field--full">
          <label>Predecessora</label>
          <select value={form.dependeDe} onChange={(e) => update('dependeDe', e.target.value)}>
            <option value="">Nenhuma</option>
            {dependeDeOptions.map((a) => (
              <option key={a.id} value={a.id}>{a.nome}</option>
            ))}
          </select>
        </div>

        {mode === 'edit' && atividade && (() => {
          const vinculados = lancamentos.filter((l) => l.atividadeId === atividade.id);
          const previsto = atividade.custoMaoDeObra + atividade.custoMaterial + atividade.custoAluguel;
          const pago = vinculados.filter((l) => l.status === 'pago').reduce((s, l) => s + l.valorPago, 0);
          const saldo = previsto - pago;
          return (
            <div className="form-field form-field--full atividade-financeiro">
              <label>Financeiro</label>
              <div className="atividade-financeiro__grid">
                <div><span>Previsto</span><strong>{formatBRL(previsto)}</strong></div>
                <div><span>Pago</span><strong className="is-success">{formatBRL(pago)}</strong></div>
                <div><span>Saldo</span><strong className={saldo > 0 ? 'is-warning' : ''}>{formatBRL(saldo)}</strong></div>
                <div><span>Lançamentos</span><strong>{vinculados.length}</strong></div>
              </div>
              {vinculados.length > 0 && (
                <ul className="atividade-financeiro__lista">
                  {vinculados.map((l) => (
                    <li key={l.id}>
                      <span>{formatDate(l.data)} — {l.descricao}</span>
                      <span>{formatBRL(l.valorPago || l.valorPrevisto)}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          );
        })()}
      </form>
    </Modal>
  );
}
