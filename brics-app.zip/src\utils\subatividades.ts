import type { Atividade, Equipamento, MaoDeObra, Material, StatusAtividade, Subatividade } from '../types/domain';
import { addDays, diffDays, isPast } from './dateUtils';

export interface SubatividadeNode {
  subatividade: Subatividade;
  depth: number;
  children: SubatividadeNode[];
}

/** Monta a árvore de subatividades: uma subatividade cuja "depende de" aponta para outra do MESMO pai vira filha dela (recuo extra); as demais ficam na raiz. */
export function buildSubatividadeTree(subatividades: Subatividade[]): SubatividadeNode[] {
  const localIds = new Set(subatividades.map((s) => s.id));
  const childrenOf = new Map<string, Subatividade[]>();

  for (const s of subatividades) {
    const isLocalDep = !!s.dependeDe && localIds.has(s.dependeDe);
    const key = isLocalDep ? s.dependeDe : 'root';
    if (!childrenOf.has(key)) childrenOf.set(key, []);
    childrenOf.get(key)!.push(s);
  }

  function build(parentKey: string, depth: number): SubatividadeNode[] {
    const kids = (childrenOf.get(parentKey) ?? []).slice().sort((a, b) => a.ordem - b.ordem);
    return kids.map((s) => ({ subatividade: s, depth, children: build(s.id, depth + 1) }));
  }

  return build('root', 0);
}

export function flattenSubatividadeTree(nodes: SubatividadeNode[]): { subatividade: Subatividade; depth: number }[] {
  const out: { subatividade: Subatividade; depth: number }[] = [];
  for (const n of nodes) {
    out.push({ subatividade: n.subatividade, depth: n.depth });
    out.push(...flattenSubatividadeTree(n.children));
  }
  return out;
}

/** Lista de subatividades já ordenada hierarquicamente (predecessora sempre antes da dependente), com profundidade de recuo. */
export function getOrderedSubatividades(subatividades: Subatividade[]): { subatividade: Subatividade; depth: number }[] {
  return flattenSubatividadeTree(buildSubatividadeTree(subatividades));
}

function findPredecessorDataFim(predecessorId: string, atividades: Atividade[]): string | undefined {
  for (const a of atividades) {
    if (a.id === predecessorId) return a.dataFim;
    const found = a.subatividades.find((s) => s.id === predecessorId);
    if (found) return found.dataFim;
  }
  return undefined;
}

/** Se a predecessora é de outro pai (ou é uma atividade top-level), ajusta dataInicio/dataFim da subatividade para começar 1 dia após o fim da predecessora, preservando a duração. Se a predecessora é irmã (mesmo pai), não mexe em datas — só a hierarquia visual muda. */
export function resolveSubatividadeDates(sub: Subatividade, atividades: Atividade[], irmas: Subatividade[]): Subatividade {
  if (!sub.dependeDe) return sub;
  const isSameParent = irmas.some((s) => s.id === sub.dependeDe);
  if (isSameParent) return sub;

  const predecessorFim = findPredecessorDataFim(sub.dependeDe, atividades);
  if (!predecessorFim) return sub;

  const duracao = Math.max(0, diffDays(sub.dataInicio, sub.dataFim));
  const novaDataInicio = addDays(predecessorFim, 1);
  const novaDataFim = addDays(novaDataInicio, duracao);
  return { ...sub, dataInicio: novaDataInicio, dataFim: novaDataFim };
}

export interface ParentAggregates {
  dataInicio: string;
  dataFim: string;
  custoMaoDeObra: number;
  custoMaterial: number;
  custoAluguel: number;
  materiaisNecessarios: Material[];
  maoDeObraNecessaria: MaoDeObra[];
  equipamentosAluguel: Equipamento[];
}

/** Agregados efetivos da atividade a partir das subatividades: datas (menor início, maior fim), custos (soma) e materiais/mão de obra/equipamentos (concatenados). Sem subatividades, mantém os valores atuais da própria atividade (fallback). */
export function recomputeParentAggregates(atividade: Atividade): ParentAggregates {
  if (atividade.subatividades.length === 0) {
    return {
      dataInicio: atividade.dataInicio,
      dataFim: atividade.dataFim,
      custoMaoDeObra: atividade.custoMaoDeObra,
      custoMaterial: atividade.custoMaterial,
      custoAluguel: atividade.custoAluguel,
      materiaisNecessarios: atividade.materiaisNecessarios,
      maoDeObraNecessaria: atividade.maoDeObraNecessaria,
      equipamentosAluguel: atividade.equipamentosAluguel,
    };
  }
  const subs = atividade.subatividades;
  const inicios = subs.map((s) => s.dataInicio);
  const fins = subs.map((s) => s.dataFim);
  return {
    dataInicio: inicios.reduce((min, d) => (d < min ? d : min)),
    dataFim: fins.reduce((max, d) => (d > max ? d : max)),
    custoMaoDeObra: subs.reduce((sum, s) => sum + s.custoMaoDeObra, 0),
    custoMaterial: subs.reduce((sum, s) => sum + s.custoMaterial, 0),
    custoAluguel: subs.reduce((sum, s) => sum + s.custoAluguel, 0),
    materiaisNecessarios: subs.flatMap((s) => s.materiaisNecessarios),
    maoDeObraNecessaria: subs.flatMap((s) => s.maoDeObraNecessaria),
    equipamentosAluguel: subs.flatMap((s) => s.equipamentosAluguel),
  };
}

export type SubatividadeDisplayStatus = StatusAtividade | 'atrasada';

/** Status de exibição derivado (não altera o campo `status` armazenado): concluída > atrasada (dataFim já passou e não foi concluída) > em andamento (marcada como iniciada) > pendente. */
export function getSubatividadeDisplayStatus(s: Subatividade): SubatividadeDisplayStatus {
  if (s.concluida) return 'concluida';
  if (isPast(s.dataFim)) return 'atrasada';
  if (s.iniciada) return 'em_andamento';
  return 'pendente';
}

/** Numeração hierárquica: "2" para atividade top-level, "2.1" para subatividade. */
export function getTaskNumber(atividades: Atividade[], id: string): string {
  const parentIndex = atividades.findIndex((a) => a.id === id);
  if (parentIndex !== -1) return String(parentIndex + 1);

  for (let i = 0; i < atividades.length; i++) {
    const ordered = getOrderedSubatividades(atividades[i].subatividades);
    const subIndex = ordered.findIndex(({ subatividade }) => subatividade.id === id);
    if (subIndex !== -1) return `${i + 1}.${subIndex + 1}`;
  }
  return '?';
}

export function getTaskLabel(atividades: Atividade[], id: string): string {
  for (const a of atividades) {
    if (a.id === id) return a.nome;
    const found = a.subatividades.find((s) => s.id === id);
    if (found) return found.nome;
  }
  return '';
}

/** ids que dependem (direta ou transitivamente) de `id`, considerando atividades e subatividades num único grafo — usado para excluir ciclos nos seletores de predecessora. */
export function getDescendantIds(id: string, atividades: Atividade[]): Set<string> {
  const edges: { id: string; dependeDe: string[] }[] = [];
  for (const a of atividades) {
    edges.push({ id: a.id, dependeDe: a.dependeDe });
    for (const s of a.subatividades) {
      edges.push({ id: s.id, dependeDe: s.dependeDe ? [s.dependeDe] : [] });
    }
  }

  const descendants = new Set<string>();
  let changed = true;
  while (changed) {
    changed = false;
    for (const e of edges) {
      if (e.dependeDe.some((dep) => dep === id || descendants.has(dep)) && !descendants.has(e.id)) {
        descendants.add(e.id);
        changed = true;
      }
    }
  }
  return descendants;
}
