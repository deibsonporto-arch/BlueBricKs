import { useState } from 'react';
import { Link } from 'react-router-dom';
import { IconBell, IconDatabaseExport, IconUserCircle } from '@tabler/icons-react';
import { CURRENT_USER } from '../../utils/currentUser';
import { BackupModal } from './BackupModal';
import './AppHeader.css';

export function AppHeader() {
  const [backupModalOpen, setBackupModalOpen] = useState(false);

  return (
    <header className="app-header">
      <Link to="/obras" className="app-header__logo">
        BRICS
      </Link>
      <div className="app-header__right">
        <Link to="/modelos" className="app-header__nav-link">
          Modelos
        </Link>
        <Link to="/materiais" className="app-header__nav-link">
          Materiais
        </Link>
        <button type="button" className="app-header__nav-link app-header__nav-link--btn" onClick={() => setBackupModalOpen(true)}>
          <IconDatabaseExport size={16} /> Backup
        </button>
        <button type="button" className="app-header__icon-btn" aria-label="Notificações">
          <IconBell size={20} stroke={1.75} />
        </button>
        <div className="app-header__user">
          <IconUserCircle size={24} stroke={1.5} />
          <span>{CURRENT_USER}</span>
        </div>
      </div>

      <BackupModal open={backupModalOpen} onClose={() => setBackupModalOpen(false)} />
    </header>
  );
}
