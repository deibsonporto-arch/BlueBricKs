import type { ItemProvidenciado } from '../../types/domain';
import { createLocalStorageRepository } from './localStorageRepository';

export const itemProvidenciadoRepository = createLocalStorageRepository<ItemProvidenciado>('itens_providenciados');
