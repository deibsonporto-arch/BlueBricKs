import { obraRepository } from './repositories/obraRepository';
import { atividadeRepository } from './repositories/atividadeRepository';
import { templateRepository } from './repositories/templateRepository';
import { seedObras } from '../mock/seedObras';
import { seedAtividades } from '../mock/seedAtividades';
import { seedTemplates } from '../mock/seedTemplates';

export function ensureSeeded(): void {
  if (obraRepository.list().length > 0) return;
  seedObras.forEach((o) => obraRepository.create(o));
  seedAtividades.forEach((a) => atividadeRepository.create(a));
  seedTemplates.forEach((t) => templateRepository.create(t));
}
