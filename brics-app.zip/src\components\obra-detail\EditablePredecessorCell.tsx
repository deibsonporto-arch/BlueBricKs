import { useState } from 'react';
import { IconLink } from '@tabler/icons-react';
import './EditableCells.css';

export interface PredecessorOption {
  id: string;
  label: string;
}

interface EditablePredecessorCellProps {
  value: string;
  options: PredecessorOption[];
  onSave: (newValue: string) => void;
}

export function EditablePredecessorCell({ value, options, onSave }: EditablePredecessorCellProps) {
  const [editing, setEditing] = useState(false);
  const selected = options.find((o) => o.id === value);

  if (editing) {
    return (
      <select
        className="editable-cell__input"
        defaultValue={value}
        autoFocus
        onBlur={() => setEditing(false)}
        onChange={(e) => {
          onSave(e.target.value);
          setEditing(false);
        }}
      >
        <option value="">Nenhuma</option>
        {options.map((o) => (
          <option key={o.id} value={o.id}>{o.label}</option>
        ))}
      </select>
    );
  }

  return (
    <span className="editable-cell" onClick={() => setEditing(true)} title="Clique para editar">
      {selected ? (
        <span className="dep-tag"><IconLink size={12} /> {selected.label}</span>
      ) : (
        <span className="atividades-table__muted">—</span>
      )}
    </span>
  );
}
