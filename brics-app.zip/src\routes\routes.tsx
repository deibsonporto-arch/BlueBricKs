export const ROUTES = {
  obras: '/obras',
  obraDetail: (id: string) => `/obras/${id}`,
  obraVisaoGeral: (id: string) => `/obras/${id}/visao-geral`,
  obraPmoMensal: (id: string) => `/obras/${id}/pmo-mensal`,
  obraDiarioDeObra: (id: string) => `/obras/${id}/diario-de-obra`,
  obraProximaSemana: (id: string) => `/obras/${id}/proxima-semana`,
  obraMapaCotacao: (id: string) => `/obras/${id}/mapa-cotacao`,
  obraFinanceiro: (id: string) => `/obras/${id}/financeiro`,
};

export const OBRA_TABS: { path: string; label: string }[] = [
  { path: 'visao-geral', label: 'Visão Geral' },
  { path: 'pmo-mensal', label: 'PMO Mensal' },
  { path: 'diario-de-obra', label: 'Diário de Obra' },
  { path: 'proxima-semana', label: 'Próxima Semana' },
  { path: 'mapa-cotacao', label: 'Mapa de Cotação' },
  { path: 'financeiro', label: 'Financeiro' },
];
