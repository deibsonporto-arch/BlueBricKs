import { useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import { IconPlus } from '@tabler/icons-react';
import { useAtividades } from '../../hooks/useAtividades';
import { useCotacoes } from '../../hooks/useCotacoes';
import { CotacoesTable } from '../../components/mapa-cotacao/CotacoesTable';
import { CotacaoFormModal } from '../../components/mapa-cotacao/CotacaoFormModal';
import { EmptyState } from '../../components/common/EmptyState';
import './MapaDeCotacaoTab.css';

export function MapaDeCotacaoTab() {
  const { id } = useParams<{ id: string }>();
  const obraId = id!;
  const { atividades } = useAtividades(obraId);
  const { cotacoes, aprovarCotacao, refresh } = useCotacoes(obraId);

  const [modalOpen, setModalOpen] = useState(false);
  const [filtroAtividade, setFiltroAtividade] = useState('');

  const cotacoesFiltradas = useMemo(
    () => (filtroAtividade ? cotacoes.filter((c) => c.atividadeId === filtroAtividade) : cotacoes),
    [cotacoes, filtroAtividade],
  );

  return (
    <div style={{ paddingBottom: 40 }}>
      <div className="mapa-cotacao-header">
        <div className="mapa-cotacao-filter">
          <label>Filtrar por atividade</label>
          <select value={filtroAtividade} onChange={(e) => setFiltroAtividade(e.target.value)}>
            <option value="">Todas</option>
            {atividades.map((a) => (
              <option key={a.id} value={a.id}>{a.nome}</option>
            ))}
          </select>
        </div>
        <button type="button" className="btn btn-primary" onClick={() => setModalOpen(true)}>
          <IconPlus size={16} /> Nova cotação
        </button>
      </div>

      <div className="mapa-cotacao-card">
        {cotacoesFiltradas.length === 0 ? (
          <EmptyState
            title="Nenhuma cotação encontrada"
            description="Cadastre uma nova cotação e compare valores de diferentes fornecedores para cada item ou serviço."
          />
        ) : (
          <CotacoesTable
            cotacoes={cotacoesFiltradas}
            atividades={atividades}
            onAprovar={aprovarCotacao}
            onFiltrarPorAtividade={setFiltroAtividade}
          />
        )}
      </div>

      <CotacaoFormModal
        open={modalOpen}
        obraId={obraId}
        atividades={atividades}
        onClose={() => setModalOpen(false)}
        onSaved={() => {
          setModalOpen(false);
          refresh();
        }}
      />
    </div>
  );
}
