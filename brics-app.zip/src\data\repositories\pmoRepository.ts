import type { PmoEntry } from '../../types/domain';
import { createLocalStorageRepository } from './localStorageRepository';

export const pmoRepository = createLocalStorageRepository<PmoEntry>('pmo_entries');
