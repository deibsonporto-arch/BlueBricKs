import { useEffect, useState } from 'react';
import { IconPaperclip, IconTrash } from '@tabler/icons-react';
import { Modal } from '../common/Modal';
import { FornecedorPicker } from './FornecedorPicker';
import type {
  Anexo,
  Atividade,
  CategoriaLancamento,
  DadosPagamento,
  Fornecedor,
  FormaPagamento,
  HistoricoEntry,
  LancamentoFinanceiro,
  StatusLancamento,
} from '../../types/domain';
import { useLancamentos } from '../../hooks/useLancamentos';
import { generateId } from '../../utils/id';
import { todayISO, formatDate } from '../../utils/dateUtils';
import { formatBRL } from '../../utils/currency';
import { CURRENT_USER } from '../../utils/currentUser';
import { downloadDataUrl } from '../../utils/downloadDataUrl';
import './LancamentoFormModal.css';

interface LancamentoFormModalProps {
  open: boolean;
  mode: 'create' | 'edit';
  obraId: string;
  lancamento?: LancamentoFinanceiro;
  fornecedores: Fornecedor[];
  atividades: Atividade[];
  onClose: () => void;
  onSaved: () => void;
}

const CATEGORIA_OPTIONS: { value: CategoriaLancamento; label: string }[] = [
  { value: 'mao_de_obra', label: 'Mão de obra' },
  { value: 'material', label: 'Material' },
  { value: 'aluguel', label: 'Aluguel' },
  { value: 'servico', label: 'Serviço' },
  { value: 'taxa', label: 'Taxa' },
];

const FORMA_PAGAMENTO_OPTIONS: { value: FormaPagamento; label: string }[] = [
  { value: 'pix', label: 'PIX' },
  { value: 'boleto', label: 'Boleto' },
  { value: 'transferencia', label: 'Transferência' },
  { value: 'dinheiro', label: 'Dinheiro' },
  { value: 'cartao', label: 'Cartão' },
];

const STATUS_OPTIONS: { value: StatusLancamento; label: string }[] = [
  { value: 'pendente', label: 'Pendente' },
  { value: 'pago', label: 'Pago' },
  { value: 'atrasado', label: 'Atrasado' },
];

const STATUS_LABEL: Record<StatusLancamento, string> = Object.fromEntries(STATUS_OPTIONS.map((s) => [s.value, s.label])) as Record<StatusLancamento, string>;

const MAX_ANEXO_BYTES = 4 * 1024 * 1024;

interface FormState {
  data: string;
  dataVencimento: string;
  fornecedorId: string;
  atividadeId: string;
  descricao: string;
  categoria: CategoriaLancamento;
  valorPrevisto: string;
  valorPago: string;
  formaPagamento: FormaPagamento;
  dadosPagamento: DadosPagamento;
  nf: boolean;
  numeroNF: string;
  status: StatusLancamento;
  anexos: Anexo[];
}

function toFormState(l?: LancamentoFinanceiro): FormState {
  return {
    data: l?.data ?? todayISO(),
    dataVencimento: l?.dataVencimento ?? todayISO(),
    fornecedorId: l?.fornecedorId ?? '',
    atividadeId: l?.atividadeId ?? '',
    descricao: l?.descricao ?? '',
    categoria: l?.categoria ?? 'material',
    valorPrevisto: l ? String(l.valorPrevisto) : '',
    valorPago: l ? String(l.valorPago) : '',
    formaPagamento: l?.formaPagamento ?? 'pix',
    dadosPagamento: l?.dadosPagamento ?? {},
    nf: l?.nf ?? false,
    numeroNF: l?.numeroNF ?? '',
    status: l?.status ?? 'pendente',
    anexos: l?.anexos ?? [],
  };
}

function buildHistoricoResumo(antigo: LancamentoFinanceiro, novo: ReturnType<typeof toBase>, fornecedores: Fornecedor[]): string {
  const mudancas: string[] = [];
  const nomeFornecedor = (id?: string) => fornecedores.find((f) => f.id === id)?.nome ?? 'nenhum';

  if (antigo.descricao !== novo.descricao) mudancas.push(`Descrição alterada para "${novo.descricao}"`);
  if (antigo.valorPago !== novo.valorPago) mudancas.push(`Valor pago alterado de ${formatBRL(antigo.valorPago)} para ${formatBRL(novo.valorPago)}`);
  if (antigo.valorPrevisto !== novo.valorPrevisto) mudancas.push(`Valor previsto alterado de ${formatBRL(antigo.valorPrevisto)} para ${formatBRL(novo.valorPrevisto)}`);
  if (antigo.status !== novo.status) mudancas.push(`Status alterado de ${STATUS_LABEL[antigo.status]} para ${STATUS_LABEL[novo.status]}`);
  if (antigo.fornecedorId !== novo.fornecedorId) mudancas.push(`Fornecedor alterado de ${nomeFornecedor(antigo.fornecedorId)} para ${nomeFornecedor(novo.fornecedorId)}`);
  if (antigo.dataVencimento !== novo.dataVencimento) mudancas.push(`Vencimento alterado de ${formatDate(antigo.dataVencimento)} para ${formatDate(novo.dataVencimento)}`);
  if (antigo.anexos.length !== novo.anexos.length) mudancas.push(`Anexos alterados (${antigo.anexos.length} → ${novo.anexos.length})`);

  return mudancas.length > 0 ? mudancas.join('; ') : 'Lançamento salvo sem alterações de campos rastreados';
}

function toBase(form: FormState, obraId: string) {
  return {
    obraId,
    data: form.data,
    dataVencimento: form.dataVencimento,
    fornecedorId: form.fornecedorId || undefined,
    atividadeId: form.atividadeId || undefined,
    descricao: form.descricao,
    categoria: form.categoria,
    valorPrevisto: Number(form.valorPrevisto) || 0,
    valorPago: Number(form.valorPago) || 0,
    formaPagamento: form.formaPagamento,
    dadosPagamento: form.dadosPagamento,
    nf: form.nf,
    numeroNF: form.numeroNF || undefined,
    status: form.status,
    anexos: form.anexos,
  };
}

export function LancamentoFormModal({ open, mode, obraId, lancamento, fornecedores, atividades, onClose, onSaved }: LancamentoFormModalProps) {
  const { createLancamento, updateLancamento } = useLancamentos(obraId);
  const [form, setForm] = useState<FormState>(() => toFormState(lancamento));
  const [anexoErro, setAnexoErro] = useState('');

  useEffect(() => {
    if (open) { setForm(toFormState(lancamento)); setAnexoErro(''); }
  }, [open, lancamento]);

  function update<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  function updateDadosPagamento<K extends keyof DadosPagamento>(key: K, value: DadosPagamento[K]) {
    setForm((f) => ({ ...f, dadosPagamento: { ...f.dadosPagamento, [key]: value } }));
  }

  function handleAnexoChange(e: React.ChangeEvent<HTMLInputElement>) {
    const files = e.target.files;
    if (!files) return;
    setAnexoErro('');
    Array.from(files).forEach((file) => {
      if (file.size > MAX_ANEXO_BYTES) {
        setAnexoErro(`"${file.name}" tem mais de 4MB e não foi anexado — arquivos grandes podem estourar o espaço local do navegador.`);
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        const dataUrl = reader.result as string;
        setForm((f) => ({ ...f, anexos: [...f.anexos, { id: generateId(), nome: file.name, tipo: file.type, dataUrl }] }));
      };
      reader.readAsDataURL(file);
    });
    e.target.value = '';
  }

  function removeAnexo(id: string) {
    setForm((f) => ({ ...f, anexos: f.anexos.filter((a) => a.id !== id) }));
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const now = new Date().toISOString();
    const base = toBase(form, obraId);

    if (mode === 'create') {
      const historico: HistoricoEntry[] = [{ data: now, usuario: CURRENT_USER, resumo: 'Lançamento criado' }];
      const novo: LancamentoFinanceiro = {
        id: generateId(),
        createdBy: CURRENT_USER,
        updatedBy: CURRENT_USER,
        historico,
        createdAt: now,
        updatedAt: now,
        ...base,
      };
      createLancamento(novo).then(onSaved);
    } else if (lancamento) {
      const resumo = buildHistoricoResumo(lancamento, base, fornecedores);
      const historico: HistoricoEntry[] = [...lancamento.historico, { data: now, usuario: CURRENT_USER, resumo }];
      updateLancamento(lancamento.id, { ...base, updatedBy: CURRENT_USER, historico, updatedAt: now }).then(onSaved);
    }
  }

  return (
    <Modal
      open={open}
      title={mode === 'create' ? 'Novo lançamento' : 'Editar lançamento'}
      onClose={onClose}
      width={760}
      footer={
        <>
          <button type="button" className="btn btn-secondary" onClick={onClose}>Cancelar</button>
          <button type="submit" form="lancamento-form" className="btn btn-primary">Salvar</button>
        </>
      }
    >
      <form id="lancamento-form" className="form-grid" onSubmit={handleSubmit}>
        <div className="form-field">
          <label>Data</label>
          <input required type="date" value={form.data} onChange={(e) => update('data', e.target.value)} />
        </div>
        <div className="form-field">
          <label>Data de vencimento</label>
          <input required type="date" value={form.dataVencimento} onChange={(e) => update('dataVencimento', e.target.value)} />
        </div>

        <div className="form-field form-field--full">
          <label>Fornecedor</label>
          <FornecedorPicker fornecedores={fornecedores} value={form.fornecedorId} onChange={(id) => update('fornecedorId', id)} />
        </div>

        <div className="form-field form-field--full">
          <label>Etapa/Atividade vinculada</label>
          <select value={form.atividadeId} onChange={(e) => update('atividadeId', e.target.value)}>
            <option value="">Nenhuma</option>
            {atividades.map((a) => <option key={a.id} value={a.id}>{a.nome}</option>)}
          </select>
        </div>

        <div className="form-field form-field--full">
          <label>Descrição</label>
          <input required value={form.descricao} onChange={(e) => update('descricao', e.target.value)} />
        </div>

        <div className="form-field">
          <label>Categoria</label>
          <select value={form.categoria} onChange={(e) => update('categoria', e.target.value as CategoriaLancamento)}>
            {CATEGORIA_OPTIONS.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
          </select>
        </div>
        <div className="form-field">
          <label>Forma de pagamento</label>
          <select value={form.formaPagamento} onChange={(e) => update('formaPagamento', e.target.value as FormaPagamento)}>
            {FORMA_PAGAMENTO_OPTIONS.map((f) => <option key={f.value} value={f.value}>{f.label}</option>)}
          </select>
        </div>

        {form.formaPagamento === 'pix' && (
          <div className="form-field form-field--full lancamento-dados-pagamento">
            <label>Dados do PIX</label>
            <div className="lancamento-dados-pagamento__grid">
              <input placeholder="Chave PIX" value={form.dadosPagamento.pixChave ?? ''} onChange={(e) => updateDadosPagamento('pixChave', e.target.value)} />
              <input placeholder="Nome do favorecido" value={form.dadosPagamento.pixFavorecido ?? ''} onChange={(e) => updateDadosPagamento('pixFavorecido', e.target.value)} />
              <input placeholder="Banco" value={form.dadosPagamento.pixBanco ?? ''} onChange={(e) => updateDadosPagamento('pixBanco', e.target.value)} />
            </div>
          </div>
        )}
        {form.formaPagamento === 'boleto' && (
          <div className="form-field form-field--full lancamento-dados-pagamento">
            <label>Dados do boleto</label>
            <div className="lancamento-dados-pagamento__grid">
              <input placeholder="Linha digitável" value={form.dadosPagamento.boletoLinhaDigitavel ?? ''} onChange={(e) => updateDadosPagamento('boletoLinhaDigitavel', e.target.value)} />
              <input placeholder="Código de barras" value={form.dadosPagamento.boletoCodigoBarras ?? ''} onChange={(e) => updateDadosPagamento('boletoCodigoBarras', e.target.value)} />
              <input placeholder="Banco emissor" value={form.dadosPagamento.boletoBancoEmissor ?? ''} onChange={(e) => updateDadosPagamento('boletoBancoEmissor', e.target.value)} />
            </div>
          </div>
        )}
        {form.formaPagamento === 'transferencia' && (
          <div className="form-field form-field--full lancamento-dados-pagamento">
            <label>Dados da transferência</label>
            <div className="lancamento-dados-pagamento__grid">
              <input placeholder="Banco" value={form.dadosPagamento.transferenciaBanco ?? ''} onChange={(e) => updateDadosPagamento('transferenciaBanco', e.target.value)} />
              <input placeholder="Agência" value={form.dadosPagamento.transferenciaAgencia ?? ''} onChange={(e) => updateDadosPagamento('transferenciaAgencia', e.target.value)} />
              <input placeholder="Conta" value={form.dadosPagamento.transferenciaConta ?? ''} onChange={(e) => updateDadosPagamento('transferenciaConta', e.target.value)} />
              <input placeholder="Tipo de conta" value={form.dadosPagamento.transferenciaTipoConta ?? ''} onChange={(e) => updateDadosPagamento('transferenciaTipoConta', e.target.value)} />
            </div>
          </div>
        )}

        <div className="form-field">
          <label>Valor previsto (R$)</label>
          <input type="number" min={0} step="0.01" value={form.valorPrevisto} onChange={(e) => update('valorPrevisto', e.target.value)} />
        </div>
        <div className="form-field">
          <label>Valor pago (R$)</label>
          <input type="number" min={0} step="0.01" value={form.valorPago} onChange={(e) => update('valorPago', e.target.value)} />
        </div>

        <div className="form-field">
          <label>Status</label>
          <select value={form.status} onChange={(e) => update('status', e.target.value as StatusLancamento)}>
            {STATUS_OPTIONS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
          </select>
        </div>
        <div className="form-field">
          <label style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <input type="checkbox" checked={form.nf} onChange={(e) => update('nf', e.target.checked)} style={{ width: 'auto' }} />
            Emite NF
          </label>
          {form.nf && (
            <input placeholder="Número da NF" value={form.numeroNF} onChange={(e) => update('numeroNF', e.target.value)} />
          )}
        </div>

        <div className="form-field form-field--full">
          <label>Anexos (Nota Fiscal, boletos, comprovantes, contratos)</label>
          <label className="btn btn-secondary lancamento-anexo-btn">
            <IconPaperclip size={16} /> Anexar arquivo
            <input type="file" multiple onChange={handleAnexoChange} hidden />
          </label>
          {anexoErro && <p className="lancamento-anexo-erro">{anexoErro}</p>}
          {form.anexos.length > 0 && (
            <ul className="lancamento-anexos-list">
              {form.anexos.map((a) => (
                <li key={a.id}>
                  <button type="button" className="lancamento-anexo-nome" onClick={() => downloadDataUrl(a.dataUrl, a.nome)}>{a.nome}</button>
                  <button type="button" onClick={() => removeAnexo(a.id)} aria-label="Remover anexo">
                    <IconTrash size={14} />
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        {mode === 'edit' && lancamento && lancamento.historico.length > 0 && (
          <div className="form-field form-field--full">
            <label>Histórico</label>
            <ul className="lancamento-historico-list">
              {[...lancamento.historico].reverse().map((h, i) => (
                <li key={i}>
                  <span className="lancamento-historico-data">{formatDate(h.data.slice(0, 10))} — {h.usuario}</span>
                  <span>{h.resumo}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </form>
    </Modal>
  );
}
