import { IconCheck, IconLink } from '@tabler/icons-react';
import type { Atividade, Cotacao } from '../../types/domain';
import { melhorFornecedor } from '../../hooks/useCotacoes';
import { formatBRL } from '../../utils/currency';
import { formatDate } from '../../utils/dateUtils';
import './CotacoesTable.css';

const STATUS_LABEL: Record<Cotacao['status'], string> = {
  em_cotacao: 'Em cotação',
  aguardando_aprovacao: 'Aguardando aprovação',
  aprovado: 'Aprovado',
};

interface CotacoesTableProps {
  cotacoes: Cotacao[];
  atividades: Atividade[];
  onAprovar: (id: string) => void;
  onFiltrarPorAtividade: (atividadeId: string) => void;
}

export function CotacoesTable({ cotacoes, atividades, onAprovar, onFiltrarPorAtividade }: CotacoesTableProps) {
  const maxFornecedores = Math.max(0, ...cotacoes.map((c) => c.fornecedores.length));
  const colunas = Array.from({ length: maxFornecedores }, (_, i) => i);

  return (
    <div className="scroll-x">
      <table className="cotacoes-table">
        <thead>
          <tr>
            <th>Item</th>
            <th>Responsável</th>
            <th>Atividade vinculada</th>
            <th>Previsto</th>
            {colunas.map((i) => (
              <th key={i}>Fornecedor {i + 1}</th>
            ))}
            <th>Melhor opção</th>
            <th>Tipo</th>
            <th>NF</th>
            <th>Status</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {cotacoes.map((c) => {
            const melhor = melhorFornecedor(c);
            const atividade = atividades.find((a) => a.id === c.atividadeId);
            const menorValor = melhor?.valor;
            const totalPrevisto = c.quantidade * c.valorUnitarioPrevisto;
            const acimaDoPrevisto = melhor !== undefined && totalPrevisto > 0 && melhor.valor > totalPrevisto;

            return (
              <tr key={c.id}>
                <td className="cotacoes-table__item">
                  {c.itemServico}
                  {c.descricaoServico && <div className="cotacoes-table__desc">{c.descricaoServico}</div>}
                </td>
                <td className="cotacoes-table__responsavel">
                  <div>{c.responsavel || '—'}</div>
                  <div className="cotacoes-table__muted">{formatDate(c.data)}</div>
                </td>
                <td>
                  {atividade ? (
                    <button type="button" className="atividade-link-pill" onClick={() => onFiltrarPorAtividade(atividade.id)}>
                      <IconLink size={12} /> {atividade.nome}
                    </button>
                  ) : (
                    <span className="cotacoes-table__muted">—</span>
                  )}
                </td>
                <td>
                  {totalPrevisto > 0 ? (
                    <>
                      <div>{formatBRL(totalPrevisto)}</div>
                      <div className="cotacoes-table__muted">{c.quantidade} {c.unidade} × {formatBRL(c.valorUnitarioPrevisto)}</div>
                    </>
                  ) : (
                    <span className="cotacoes-table__muted">—</span>
                  )}
                </td>
                {colunas.map((i) => {
                  const f = c.fornecedores[i];
                  if (!f) return <td key={i}>—</td>;
                  const isMenor = f.valor === menorValor;
                  return (
                    <td key={i} className={isMenor ? 'cotacoes-table__cell-menor' : ''}>
                      <div>{f.nome}</div>
                      <div className="cotacoes-table__valor">{formatBRL(f.valor)}</div>
                      {(f.marca || f.numeroOrcamento) && (
                        <div className="cotacoes-table__muted">
                          {f.marca}{f.marca && f.numeroOrcamento ? ' · ' : ''}{f.numeroOrcamento && `Orç. ${f.numeroOrcamento}`}
                        </div>
                      )}
                    </td>
                  );
                })}
                <td className="cotacoes-table__melhor">
                  {melhor ? melhor.nome : '—'}
                  {acimaDoPrevisto && <div className="cotacoes-table__acima-previsto">acima do previsto</div>}
                </td>
                <td>
                  {melhor && (
                    <span className={`tipo-badge tipo-badge--${melhor.tipo === 'PJ' ? 'pj' : 'informal'}`}>
                      {melhor.tipo === 'PJ' ? 'PJ' : 'Informal'}
                    </span>
                  )}
                </td>
                <td>
                  {melhor && (
                    <span className={`nf-badge nf-badge--${melhor.emiteNF ? 'sim' : 'nao'}`}>
                      {melhor.emiteNF ? 'Sim' : 'Não'}
                    </span>
                  )}
                </td>
                <td>
                  <span className={`cotacao-status-pill cotacao-status-pill--${c.status}`}>{STATUS_LABEL[c.status]}</span>
                </td>
                <td>
                  {c.status !== 'aprovado' && (
                    <button type="button" className="btn btn-secondary" onClick={() => onAprovar(c.id)}>
                      <IconCheck size={14} /> Aprovar
                    </button>
                  )}
                </td>
              </tr>
            );
          })}
          {cotacoes.length === 0 && (
            <tr>
              <td colSpan={9 + maxFornecedores} className="cotacoes-table__empty">Nenhuma cotação cadastrada ainda.</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
