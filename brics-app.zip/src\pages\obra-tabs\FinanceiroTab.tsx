import { useMemo, useState } from 'react';
import { useParams } from 'react-router-dom';
import { IconDownload, IconPlus, IconUsers } from '@tabler/icons-react';
import { useFornecedores } from '../../hooks/useFornecedores';
import { useLancamentos } from '../../hooks/useLancamentos';
import { useAtividades } from '../../hooks/useAtividades';
import { useObras } from '../../hooks/useObras';
import { ResumoFinanceiro } from '../../components/financeiro/ResumoFinanceiro';
import { GastosPorCategoriaChart } from '../../components/financeiro/GastosPorCategoriaChart';
import { CustosPorEtapaSection } from '../../components/financeiro/CustosPorEtapaSection';
import { ContasAPagarPanel } from '../../components/financeiro/ContasAPagarPanel';
import { LancamentosTable } from '../../components/financeiro/LancamentosTable';
import { LancamentoFormModal } from '../../components/financeiro/LancamentoFormModal';
import { FornecedoresListModal } from '../../components/financeiro/FornecedoresListModal';
import type { CategoriaLancamento, LancamentoFinanceiro, StatusLancamento } from '../../types/domain';
import { exportToCsv } from '../../utils/csvExport';
import { formatDate } from '../../utils/dateUtils';
import { CURRENT_USER } from '../../utils/currentUser';
import type { VencimentoBucket } from '../../utils/contasAPagar';
import { lancamentoNoBucket } from '../../utils/contasAPagar';
import './FinanceiroTab.css';

const CATEGORIA_LABEL: Record<CategoriaLancamento, string> = {
  mao_de_obra: 'Mão de obra', material: 'Material', aluguel: 'Aluguel', servico: 'Serviço', taxa: 'Taxa',
};

const STATUS_LABEL: Record<StatusLancamento, string> = {
  pendente: 'Pendente', pago: 'Pago', atrasado: 'Atrasado',
};

export function FinanceiroTab() {
  const { id } = useParams<{ id: string }>();
  const obraId = id!;
  const { obras } = useObras();
  const obra = obras.find((o) => o.id === obraId);
  const { fornecedores, refresh: refreshFornecedores } = useFornecedores();
  const { lancamentos, updateLancamento, refresh: refreshLancamentos } = useLancamentos(obraId);
  const { atividades } = useAtividades(obraId);

  const [lancamentoModalOpen, setLancamentoModalOpen] = useState(false);
  const [lancamentoModalMode, setLancamentoModalMode] = useState<'create' | 'edit'>('create');
  const [editingLancamento, setEditingLancamento] = useState<LancamentoFinanceiro | undefined>(undefined);
  const [fornecedoresModalOpen, setFornecedoresModalOpen] = useState(false);

  const [filtroCategoria, setFiltroCategoria] = useState<CategoriaLancamento | 'todas'>('todas');
  const [filtroFornecedor, setFiltroFornecedor] = useState('');
  const [filtroAtividade, setFiltroAtividade] = useState('');
  const [filtroMes, setFiltroMes] = useState('');
  const [filtroStatus, setFiltroStatus] = useState<StatusLancamento | 'todos'>('todos');
  const [filtroVencimento, setFiltroVencimento] = useState<VencimentoBucket | null>(null);

  const lancamentosFiltrados = useMemo(() => {
    return lancamentos.filter((l) => {
      if (filtroCategoria !== 'todas' && l.categoria !== filtroCategoria) return false;
      if (filtroFornecedor && l.fornecedorId !== filtroFornecedor) return false;
      if (filtroAtividade && l.atividadeId !== filtroAtividade) return false;
      if (filtroMes && !l.data.startsWith(filtroMes)) return false;
      if (filtroStatus !== 'todos' && l.status !== filtroStatus) return false;
      if (filtroVencimento && !lancamentoNoBucket(l, filtroVencimento)) return false;
      return true;
    });
  }, [lancamentos, filtroCategoria, filtroFornecedor, filtroAtividade, filtroMes, filtroStatus, filtroVencimento]);

  if (!obra) return null;

  function openCreate() {
    setLancamentoModalMode('create');
    setEditingLancamento(undefined);
    setLancamentoModalOpen(true);
  }

  function openEdit(lancamento: LancamentoFinanceiro) {
    setLancamentoModalMode('edit');
    setEditingLancamento(lancamento);
    setLancamentoModalOpen(true);
  }

  function handleUpdateStatus(lancamento: LancamentoFinanceiro, novoStatus: StatusLancamento) {
    const now = new Date().toISOString();
    const historico = [
      ...lancamento.historico,
      { data: now, usuario: CURRENT_USER, resumo: `Status alterado de ${STATUS_LABEL[lancamento.status]} para ${STATUS_LABEL[novoStatus]}` },
    ];
    updateLancamento(lancamento.id, { status: novoStatus, updatedBy: CURRENT_USER, historico, updatedAt: now });
  }

  function handleExportCsv() {
    exportToCsv(
      `financeiro-${obraId}.csv`,
      ['Data', 'Vencimento', 'Fornecedor', 'Descrição', 'Categoria', 'Valor previsto', 'Valor pago', 'Forma pagamento', 'NF', 'Status'],
      lancamentosFiltrados.map((l) => [
        formatDate(l.data),
        formatDate(l.dataVencimento),
        fornecedores.find((f) => f.id === l.fornecedorId)?.nome ?? '',
        l.descricao,
        CATEGORIA_LABEL[l.categoria],
        l.valorPrevisto,
        l.valorPago,
        l.formaPagamento,
        l.nf ? 'Sim' : 'Não',
        l.status,
      ]),
    );
  }

  return (
    <div style={{ paddingBottom: 40 }}>
      <ContasAPagarPanel
        lancamentos={lancamentos}
        activeBucket={filtroVencimento}
        onSelectBucket={(bucket) => setFiltroVencimento((cur) => (cur === bucket ? null : bucket))}
      />
      <ResumoFinanceiro lancamentos={lancamentosFiltrados} />
      <GastosPorCategoriaChart lancamentos={lancamentosFiltrados} />
      <CustosPorEtapaSection obra={obra} lancamentos={lancamentos} atividades={atividades} />

      <div className="financeiro-card">
        <div className="financeiro-filters">
          <select value={filtroCategoria} onChange={(e) => setFiltroCategoria(e.target.value as CategoriaLancamento | 'todas')}>
            <option value="todas">Todas as categorias</option>
            {(Object.keys(CATEGORIA_LABEL) as CategoriaLancamento[]).map((c) => (
              <option key={c} value={c}>{CATEGORIA_LABEL[c]}</option>
            ))}
          </select>
          <select value={filtroFornecedor} onChange={(e) => setFiltroFornecedor(e.target.value)}>
            <option value="">Todos os fornecedores</option>
            {fornecedores.map((f) => <option key={f.id} value={f.id}>{f.nome}</option>)}
          </select>
          <select value={filtroAtividade} onChange={(e) => setFiltroAtividade(e.target.value)}>
            <option value="">Todas as etapas</option>
            {atividades.map((a) => <option key={a.id} value={a.id}>{a.nome}</option>)}
          </select>
          <input type="month" value={filtroMes} onChange={(e) => setFiltroMes(e.target.value)} />
          <select value={filtroStatus} onChange={(e) => setFiltroStatus(e.target.value as StatusLancamento | 'todos')}>
            <option value="todos">Todos os status</option>
            <option value="pendente">Pendente</option>
            <option value="pago">Pago</option>
            <option value="atrasado">Atrasado</option>
          </select>

          <div className="financeiro-filters__actions">
            <button type="button" className="btn btn-secondary" onClick={handleExportCsv}>
              <IconDownload size={16} /> Exportar CSV
            </button>
            <button type="button" className="btn btn-secondary" onClick={() => setFornecedoresModalOpen(true)}>
              <IconUsers size={16} /> Gerenciar fornecedores
            </button>
            <button type="button" className="btn btn-primary" onClick={openCreate}>
              <IconPlus size={16} /> Novo lançamento
            </button>
          </div>
        </div>

        <LancamentosTable
          lancamentos={lancamentosFiltrados}
          fornecedores={fornecedores}
          atividades={atividades}
          onEdit={openEdit}
          onFiltrarPorAtividade={setFiltroAtividade}
          onUpdateStatus={handleUpdateStatus}
        />
      </div>

      <LancamentoFormModal
        open={lancamentoModalOpen}
        mode={lancamentoModalMode}
        obraId={obraId}
        lancamento={editingLancamento}
        fornecedores={fornecedores}
        atividades={atividades}
        onClose={() => setLancamentoModalOpen(false)}
        onSaved={() => {
          setLancamentoModalOpen(false);
          refreshLancamentos();
        }}
      />
      <FornecedoresListModal
        open={fornecedoresModalOpen}
        onClose={() => { setFornecedoresModalOpen(false); refreshFornecedores(); }}
      />
    </div>
  );
}
