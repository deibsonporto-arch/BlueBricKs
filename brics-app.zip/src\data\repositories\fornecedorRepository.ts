import type { Fornecedor } from '../../types/domain';
import { createLocalStorageRepository } from './localStorageRepository';

export const fornecedorRepository = createLocalStorageRepository<Fornecedor>('fornecedores');
