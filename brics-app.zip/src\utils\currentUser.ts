export const CURRENT_USER = 'Deibson Porto';
