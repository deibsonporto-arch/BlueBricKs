import type { LancamentoFinanceiro } from '../../types/domain';
import { formatBRL } from '../../utils/currency';
import './ResumoFinanceiro.css';

interface ResumoFinanceiroProps {
  lancamentos: LancamentoFinanceiro[];
}

export function ResumoFinanceiro({ lancamentos }: ResumoFinanceiroProps) {
  const totalPrevisto = lancamentos.reduce((s, l) => s + l.valorPrevisto, 0);
  const totalPago = lancamentos.reduce((s, l) => s + l.valorPago, 0);
  const saldo = totalPrevisto - totalPago;

  return (
    <div className="resumo-financeiro">
      <div className="resumo-financeiro__card">
        <span className="resumo-financeiro__label">Total previsto</span>
        <span className="resumo-financeiro__value">{formatBRL(totalPrevisto)}</span>
      </div>
      <div className="resumo-financeiro__card">
        <span className="resumo-financeiro__label">Total pago</span>
        <span className="resumo-financeiro__value is-success">{formatBRL(totalPago)}</span>
      </div>
      <div className="resumo-financeiro__card">
        <span className="resumo-financeiro__label">Saldo restante</span>
        <span className={`resumo-financeiro__value ${saldo > 0 ? 'is-warning' : ''}`}>{formatBRL(saldo)}</span>
      </div>
    </div>
  );
}
