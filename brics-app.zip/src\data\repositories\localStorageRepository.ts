import { readCollection, writeCollection } from '../storage';
import type { Repository } from './types';

export function createLocalStorageRepository<T extends { id: string }>(key: string): Repository<T> {
  return {
    list: () => readCollection<T>(key),
    get: (id) => readCollection<T>(key).find((i) => i.id === id),
    create: (item) => {
      const all = readCollection<T>(key);
      all.push(item);
      writeCollection(key, all);
      return item;
    },
    update: (id, patch) => {
      const all = readCollection<T>(key);
      const idx = all.findIndex((i) => i.id === id);
      if (idx === -1) return undefined;
      all[idx] = { ...all[idx], ...patch };
      writeCollection(key, all);
      return all[idx];
    },
    remove: (id) => {
      writeCollection(
        key,
        readCollection<T>(key).filter((i) => i.id !== id),
      );
    },
  };
}
