import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './styles/theme.css'
import './styles/global.css'
import './styles/forms.css'
import App from './App.tsx'
import { ErrorBoundary } from './components/common/ErrorBoundary'
import { ensureSeeded } from './data/seed'

ensureSeeded()

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
)
